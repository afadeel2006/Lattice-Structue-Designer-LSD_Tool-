# -*- coding: mbcs -*-
from abaqus import*
from abaqusConstants import*
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
def createPart (X,Y,Z,R,NX,NY,NZ,SL,ZH,Material,Pyr_SL,NTZ,RadL,Pyr_Z,NPH,NPX,NPY,HFrame3,ComboBox1,Mat_Name,Den,Young,Poiss,Table):#X=X Dim , Y=Y_Dim, Z=Z_Dim , r is the strut radius 
	mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-1', type=
		DEFORMABLE_BODY)
	M=mdb.models['Model-1']
	P=M.parts['Part-1']
	P.ReferencePoint(point=(0.0, 0.0, 0.0))
	P.DatumPointByCoordinate(coords=(X, 0.0, 
		0.0))
	P.DatumPointByCoordinate(coords=(0.0, Y, 
		0.0))
	P.DatumPointByCoordinate(coords=(0.0, 0.0, 
		Z))
	P.DatumPointByCoordinate(coords=(X, Y, 
		0.0))
	P.DatumPointByCoordinate(coords=(X, 0.0, 
		Z))
	P.DatumPointByCoordinate(coords=(X, Y, 
		Z))
	P.DatumPointByCoordinate(coords=(0.0, Y, 
		Z))
	P.DatumAxisByTwoPoint(point1=
		P.referencePoints[1], point2=
		P.datums[7])
	P.DatumAxisByTwoPoint(point1=
		P.datums[4], point2=
		P.datums[6])
	P.DatumPlaneByPointNormal(normal=
		P.datums[9], point=
		P.datums[7])
	M.ConstrainedSketch(gridSpacing=25.47, name='__profile__', 
		sheetSize=1018.95, transform=
		P.MakeSketchTransform(
		sketchPlane=P.datums[11], 
		sketchPlaneSide=SIDE1, 
		sketchUpEdge=P.datums[10], 
		sketchOrientation=RIGHT, origin=(X, Y, Z)))
	P.projectReferencesOntoSketch(filter=
		COPLANAR_EDGES, sketch=M.sketches['__profile__'])
	M.sketches['__profile__'].CircleByCenterPerimeter(center=(
		0.0, 0.0), point1=(R, 0.0))
	P.SolidExtrude(depth=sqrt(X**2.+Y**2.+Z**2.), 
		flipExtrudeDirection=ON, sketch=
		M.sketches['__profile__'], sketchOrientation=RIGHT, 
		sketchPlane=P.datums[11], 
		sketchPlaneSide=SIDE1, sketchUpEdge=
		P.datums[10])
	del M.sketches['__profile__']
	P.DatumPlaneByPrincipalPlane(offset=Z/2., 
		principalPlane=XYPLANE)
	P.DatumPlaneByPrincipalPlane(offset=X/2., 
		principalPlane=YZPLANE)
	P.DatumPlaneByPrincipalPlane(offset=Y/2., 
		principalPlane=XZPLANE)
	P.Mirror(keepOriginal=ON, mirrorPlane=
		P.datums[14])
	P.Mirror(keepOriginal=ON, mirrorPlane=
		P.datums[13])
	P.DatumPlaneByOffset(flip=SIDE1, offset=8.0
		, plane=P.datums[13])
	M.ConstrainedSketch(gridSpacing=25.47, name='__profile__', 
		sheetSize=1018.95, transform=
		P.MakeSketchTransform(
		sketchPlane=P.datums[18], 
		sketchPlaneSide=SIDE1, 
		sketchUpEdge=P.datums[10], 
		sketchOrientation=RIGHT, origin=(X/2., Y/2., 10.5)))
	P.projectReferencesOntoSketch(filter=
		COPLANAR_EDGES, sketch=M.sketches['__profile__'])
	M.sketches['__profile__'].rectangle(point1=(10, X/2.0)
		, point2=(-10, 10+Y/2.0))
	M.sketches['__profile__'].rectangle(point1=(
		10, -X/2.0), point2=(-10, 
		-10))
	P.CutExtrude(flipExtrudeDirection=OFF, 
		sketch=M.sketches['__profile__'], sketchOrientation=
		RIGHT, sketchPlane=P.datums[18], 
		sketchPlaneSide=SIDE1, sketchUpEdge=
		P.datums[10])
	del M.sketches['__profile__']
	M.ConstrainedSketch(gridSpacing=0.89, name='__profile__', 
		sheetSize=35.92, transform=
		P.MakeSketchTransform(
		sketchPlane=P.datums[18], 
		sketchPlaneSide=SIDE1, 
		sketchUpEdge=P.datums[10], 
		sketchOrientation=RIGHT, origin=(X/2., Y/2., 10.5)))
	P.projectReferencesOntoSketch(filter=
		COPLANAR_EDGES, sketch=M.sketches['__profile__'])
	M.sketches['__profile__'].rectangle(point1=(-Y/2.0, 10), 
		point2=(-10, -10))
	M.sketches['__profile__'].rectangle(point1=(Y/2.0, 10), 
		point2=(10, -10))
	P.CutExtrude(flipExtrudeDirection=OFF, 
		sketch=M.sketches['__profile__'], sketchOrientation=
		RIGHT, sketchPlane=P.datums[18], 
		sketchPlaneSide=SIDE1, sketchUpEdge=
		P.datums[10])
	del M.sketches['__profile__']
	P.DatumAxisByTwoPoint(point1=
		P.datums[6], point2=
		P.datums[2])
	P.DatumPlaneByOffset(flip=SIDE1, offset=8.0
		, plane=P.datums[14])
	M.ConstrainedSketch(gridSpacing=0.95, name='__profile__', 
		sheetSize=38.33, transform=
		P.MakeSketchTransform(
		sketchPlane=P.datums[22], 
		sketchPlaneSide=SIDE1, 
		sketchUpEdge=P.datums[21], 
		sketchOrientation=RIGHT, origin=(10.5, Y/2., Z/2.)))
	P.projectReferencesOntoSketch(filter=
		COPLANAR_EDGES, sketch=M.sketches['__profile__'])
	M.sketches['__profile__'].rectangle(point1=(10, Z/2.0), 
		point2=(-10, 10))
	M.sketches['__profile__'].rectangle(point1=(10, -Z/2.0), 
		point2=(-10, -10))
	P.CutExtrude(flipExtrudeDirection=OFF, 
		sketch=M.sketches['__profile__'], sketchOrientation=
		RIGHT, sketchPlane=P.datums[22], 
		sketchPlaneSide=SIDE1, sketchUpEdge=
		P.datums[21])
	del M.sketches['__profile__']
	P.PartitionCellByDatumPlane(cells=
			P.cells.getSequenceFromMask(('[#1 ]', 
			), ), datumPlane=P.datums[14])
	P.PartitionCellByDatumPlane(cells=
			P.cells.getSequenceFromMask(('[#3 ]', 
			), ), datumPlane=P.datums[15])
	P.PartitionCellByDatumPlane(cells=
			P.cells.getSequenceFromMask(('[#f ]', 
			), ), datumPlane=P.datums[13])
	P.PartitionCellByPlaneThreePoints(cells=
			P.cells.getSequenceFromMask(('[#ff ]', 
			), ), point1=P.datums[6], point2=
			P.datums[3], point3=
			P.datums[7])
	P.PartitionCellByPlaneThreePoints(cells=
			P.cells.getSequenceFromMask(('[#fff ]', 
			), ), point1=P.datums[4], point2=
			P.datums[8], point3=
			P.datums[5])
	P.PartitionCellByPlaneThreePoints(cells=
			P.cells.getSequenceFromMask((
			'[#ffff ]', ), ), point1=P.datums[4], 
			point2=P.datums[7], point3=
			P.datums[5])
	P.PartitionCellByPlaneThreePoints(cells=
			P.cells.getSequenceFromMask((
			'[#ffffff ]', ), ), point1=P.datums[6], 
			point2=P.datums[8], point3=
			P.datums[3])
	P.PartitionCellByPlaneThreePoints(cells=
			P.cells.getSequenceFromMask((
			'[#ffffffff ]', ), ), point1=
			P.vertices[37], point2=
			P.datums[7], point3=
			P.datums[8])
	P.PartitionCellByPlaneThreePoints(cells=
			P.cells.getSequenceFromMask((
			'[#ffffffff #ff ]', ), ), point1=
			P.datums[4], point2=
			P.datums[3], point3=
			P.datums[5])
		# # For Partitions Here *************************
	if ComboBox1 == 'BCC':
		print('BCC')	
		
	elif ComboBox1 == 'BCCV':
		print('BCCV')
		TX=float(X)/2.0
		TY=float(Y)/2.0
		TXR=float(X)/2.0-R
		TYR=float(Y)/2.0-R
		print TX,TY,TXR,TYR
		M.ConstrainedSketch(name='__profile__', sheetSize=200.0)
		M.sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(0.0, R))
		M.sketches['__profile__'].ArcByCenterEnds(center=(TX, TY)
			, direction=CLOCKWISE, point1=(TX, TYR), point2=(TXR, TY))
		M.sketches['__profile__'].Line(point1=(TXR, TY), point2=(
			TX, TY))
		M.sketches['__profile__'].Line(point1=(TX, TY), point2=(
			TX, TYR))
		M.sketches['__profile__'].ArcByCenterEnds(center=(-TX, 
			TY), direction=COUNTERCLOCKWISE, point1=(-TX, TYR), point2=(-TXR, TY))
		M.sketches['__profile__'].Line(point1=(-TXR, TY), point2=(
			-TX, TY))
		M.sketches['__profile__'].Line(point1=(-TX, TY), point2=(
			-TX, TYR))
		M.sketches['__profile__'].ArcByCenterEnds(center=(-TX, 
			-TY), direction=COUNTERCLOCKWISE, point1=(-TXR, -TY), point2=(-TX, 
			-TYR))
		M.sketches['__profile__'].Line(point1=(-TXR, -TY), point2=
			(-TX, -TY))
		M.sketches['__profile__'].Line(point1=(-TX, -TY), point2=
			(-TX, -TYR))
		mdb.models['Model-1'].sketches['__profile__'].ArcByCenterEnds(center=(TX, 
			-TY), direction=COUNTERCLOCKWISE, point1=(TX, -TYR), point2=(TXR, -TY))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(TXR, -TY), point2=(
			TX, -TY))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(TX, -TY), point2=(
			TX, -TYR))
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='V_Strut', type=
			DEFORMABLE_BODY)
		mdb.models['Model-1'].parts['V_Strut'].BaseSolidExtrude(depth=Z, sketch=
			mdb.models['Model-1'].sketches['__profile__'])
		del mdb.models['Model-1'].sketches['__profile__']
		# Assembly %%%%%%%%%%%%%%%%%
		Ang=atan(TY/TX)*(180./pi)
		mdb.models['Model-1'].parts['V_Strut'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['V_Strut'].InterestingPoint(
			mdb.models['Model-1'].parts['V_Strut'].edges[36], CENTER), point2=
			mdb.models['Model-1'].parts['V_Strut'].InterestingPoint(
			mdb.models['Model-1'].parts['V_Strut'].edges[37], CENTER))
		mdb.models['Model-1'].parts['V_Strut'].DatumPlaneByPrincipalPlane(offset=0.0, 
			principalPlane=YZPLANE)
		mdb.models['Model-1'].parts['V_Strut'].DatumPlaneByRotation(angle=90-Ang, axis=
			mdb.models['Model-1'].parts['V_Strut'].datums[2], plane=
			mdb.models['Model-1'].parts['V_Strut'].datums[3])
		mdb.models['Model-1'].parts['V_Strut'].DatumPlaneByRotation(angle=Ang, axis=
			mdb.models['Model-1'].parts['V_Strut'].datums[2], plane=
			mdb.models['Model-1'].parts['V_Strut'].datums[4])
		mdb.models['Model-1'].parts['V_Strut'].DatumPlaneByRotation(angle=Ang, axis=
			mdb.models['Model-1'].parts['V_Strut'].datums[2], plane=
			mdb.models['Model-1'].parts['V_Strut'].datums[5])
		mdb.models['Model-1'].parts['V_Strut'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Strut'].cells.getSequenceFromMask(('[#10 ]', 
			), ), datumPlane=mdb.models['Model-1'].parts['V_Strut'].datums[5])
		mdb.models['Model-1'].parts['V_Strut'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Strut'].cells.getSequenceFromMask(('[#3c ]', 
			), ), datumPlane=mdb.models['Model-1'].parts['V_Strut'].datums[6])
		mdb.models['Model-1'].parts['V_Strut'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Strut'].cells.getSequenceFromMask((
			'[#3c3 ]', ), ), datumPlane=
			mdb.models['Model-1'].parts['V_Strut'].datums[4])
		mdb.models['Model-1'].parts['V_Strut'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Strut'].cells.getSequenceFromMask((
			'[#3f00 ]', ), ), datumPlane=
			mdb.models['Model-1'].parts['V_Strut'].datums[3])
		mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
		mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-1-1', 
			part=mdb.models['Model-1'].parts['Part-1'])
		mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='V_Strut-1', 
			part=mdb.models['Model-1'].parts['V_Strut'])
		mdb.models['Model-1'].rootAssembly.translate(instanceList=('V_Strut-1', ), 
			vector=(TX, TY, 0.0))
		mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(domain=GEOMETRY, 
			instances=(mdb.models['Model-1'].rootAssembly.instances['Part-1-1'], 
			mdb.models['Model-1'].rootAssembly.instances['V_Strut-1']), 
			keepIntersections=ON, name='PPP', originalInstances=DELETE)
		P=M.parts['PPP']
# ******************************************* BCCA *******************************************		
	elif ComboBox1 == 'BCCA':
		print 'BCCA'
		TX=float(X)/2
		TY=float(Y)/2
		TZ=float(Z)/2
		mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
		mdb.models['Model-1'].sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(R, 0))
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='V_Struts', type=
			DEFORMABLE_BODY)
		mdb.models['Model-1'].parts['V_Struts'].BaseSolidExtrude(depth=Z, sketch=
			mdb.models['Model-1'].sketches['__profile__'])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].parts['V_Struts'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['V_Struts'].InterestingPoint(
			mdb.models['Model-1'].parts['V_Struts'].edges[0], CENTER), point2=
			mdb.models['Model-1'].parts['V_Struts'].InterestingPoint(
			mdb.models['Model-1'].parts['V_Struts'].edges[1], CENTER))
		mdb.models['Model-1'].parts['V_Struts'].DatumPlaneByPrincipalPlane(offset=0.0, 
			principalPlane=XZPLANE)
		mdb.models['Model-1'].parts['V_Struts'].DatumPlaneByRotation(angle=45.0, axis=
			mdb.models['Model-1'].parts['V_Struts'].datums[2], plane=
			mdb.models['Model-1'].parts['V_Struts'].datums[3])
		mdb.models['Model-1'].parts['V_Struts'].DatumPlaneByRotation(angle=45.0, axis=
			mdb.models['Model-1'].parts['V_Struts'].datums[2], plane=
			mdb.models['Model-1'].parts['V_Struts'].datums[4])
		mdb.models['Model-1'].parts['V_Struts'].DatumPlaneByRotation(angle=45.0, axis=
			mdb.models['Model-1'].parts['V_Struts'].datums[2], plane=
			mdb.models['Model-1'].parts['V_Struts'].datums[5])
		mdb.models['Model-1'].parts['V_Struts'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Struts'].cells.getSequenceFromMask(('[#1 ]', 
			), ), datumPlane=mdb.models['Model-1'].parts['V_Struts'].datums[6])
		mdb.models['Model-1'].parts['V_Struts'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Struts'].cells.getSequenceFromMask(('[#3 ]', 
			), ), datumPlane=mdb.models['Model-1'].parts['V_Struts'].datums[3])
		mdb.models['Model-1'].parts['V_Struts'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Struts'].cells.getSequenceFromMask(('[#f ]', 
			), ), datumPlane=mdb.models['Model-1'].parts['V_Struts'].datums[4])
		mdb.models['Model-1'].parts['V_Struts'].PartitionCellByDatumPlane(cells=
			mdb.models['Model-1'].parts['V_Struts'].cells.getSequenceFromMask((
			'[#3f ]', ), ), datumPlane=
			mdb.models['Model-1'].parts['V_Struts'].datums[5])
		for ii in range(NZ/2):
			mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='V_Struts'+str(ii), 
				part=mdb.models['Model-1'].parts['V_Struts'])
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('V_Struts'+str(ii), ), 
				vector=(TX, TY, TZ+ii*10))
			mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(1.0, 0.0, 
				0.0), direction2=(0.0, 1.0, 0.0), instanceList=('V_Struts'+str(ii), ), number1=NX, 
					number2=NY, spacing1=X, spacing2=Y)
# ********************** Tetrahedron ****************************************		
	elif ComboBox1 == 'TETRAHEDRON':
		print 'TETRAHEDRON'
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-1', type=
			DEFORMABLE_BODY)
		M=mdb.models['Model-1']
		P=M.parts['Part-1']
		P.ReferencePoint(point=(0.0, 0.0, 0.0))
		P.DatumPointByCoordinate(coords=(SL, 0.0, 
			0.0))
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180), 0.0))
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 0.0, 
			0.0))
		P.DatumPointByMidPoint(point1=P.datums[3], point2=P.referencePoints[1])
		P.DatumPointByMidPoint(point1=P.datums[3], point2=P.datums[2])
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180)/3, 0.0))
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180)/3, ZH))
		St_Length=sqrt(((SL*cos(60*pi/180))**2+(SL*sin(60*pi/180)/3)**2)+ZH**2)
		P.DatumAxisByTwoPoint(point1=
		 P.referencePoints[1], point2=
		 P.datums[2])
		P.DatumAxisByTwoPoint(point1=
		 P.referencePoints[1], point2=
		 P.datums[3])
		P.DatumAxisByTwoPoint(point1=
		 P.datums[2], point2=
		 P.datums[3])
		P.DatumAxisByTwoPoint(point1=
		 P.referencePoints[1], point2=
		 P.datums[8]) 
		P.DatumPlaneByPointNormal(normal=
			P.datums[12], point=
			P.referencePoints[1])
		M.ConstrainedSketch(gridSpacing=26.07, name='__profile__', 
			sheetSize=1043.02, transform=
			P.MakeSketchTransform(
			sketchPlane=P.datums[13], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=P.datums[9], 
			sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
		P.projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		M.sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(R, 0.0))
		P.SolidExtrude(depth=St_Length, 
			flipExtrudeDirection=OFF, sketch=
			M.sketches['__profile__'], sketchOrientation=RIGHT, 
			sketchPlane=P.datums[13], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			P.datums[9])
		del M.sketches['__profile__']	
	###### New Try
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=XYPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.81, name='__profile__', 
			sheetSize=32.44, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[15], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[12], 
			sketchOrientation=RIGHT, origin=(0, 0, 10.0)))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(
			0, 0), point2=(SL/4.0, 
			SL*sin(60*pi/180)/2))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(SL/4.0, 
			SL*sin(60*pi/180)/2), point2=(0, SL*sin(60*pi/180)*(2.0/3.0)))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(
			0, SL*sin(60*pi/180)*(2.0/3.0)), point2=(-SL/4.0, 
			SL*sin(60*pi/180)/2))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-SL/4.0, 
			SL*sin(60*pi/180)/2), point2=(0, 0))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(
			-10, -10), point2=(10, 10))
		mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[15], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[12])
		del mdb.models['Model-1'].sketches['__profile__']
		# exit(999)
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=YZPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.91, name='__profile__', 
			sheetSize=36.52, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[17], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[11], 
			sketchOrientation=RIGHT, origin=(10.0, 0, 0)))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(0, 
			-0), point2=(5, 5))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(-ZH, 
			-SL), point2=(-10, 10))
		mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[17], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[11])
		del mdb.models['Model-1'].sketches['__profile__']
		
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[5])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[6], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[3])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#2 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].vertices[3], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-1'].datums[8])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#8 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].vertices[1], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[10], point3=
			mdb.models['Model-1'].parts['Part-1'].datums[8])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[12], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[3])
	########################### Draw HOR Strut
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-2', type=
			DEFORMABLE_BODY)
		M=mdb.models['Model-1']
		P2=M.parts['Part-2']
		P2.ReferencePoint(point=(0.0, 0.0, 0.0))
		P2.DatumPointByCoordinate(coords=(SL, 0.0, 
			0.0))
		P2.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180), 0.0))
		P2.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 0.0, 
			0.0))
		P2.DatumPointByMidPoint(point1=P.datums[3], point2=P.referencePoints[1])
		P2.DatumPointByMidPoint(point1=P.datums[3], point2=P.datums[2])
		P2.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180)/3, 0.0))
		P2.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180)/3, Z))
		P2.DatumAxisByTwoPoint(point1=
			P2.referencePoints[1], point2=
			P2.datums[2])
		P2.DatumAxisByTwoPoint(point1=
			P2.referencePoints[1], point2=
			P2.datums[3])
		P2.DatumAxisByTwoPoint(point1=
			P2.datums[2], point2=
			P2.datums[3])
		P2.DatumAxisByTwoPoint(point1=
			P2.referencePoints[1], point2=
			P2.datums[8]) 
		P2.DatumPlaneByPointNormal(normal=
			P2.datums[9], point=
			P2.referencePoints[1])
		M.ConstrainedSketch(gridSpacing=24.65, name='__profile__', 
			sheetSize=986.11, transform=
			P2.MakeSketchTransform(
			sketchPlane=P2.datums[13], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=P2.datums[10], 
			sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
		P2.projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=M.sketches['__profile__'])
		M.sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(R, 0.0))
		P2.SolidExtrude(depth=SL, 
			flipExtrudeDirection=OFF, sketch=
			M.sketches['__profile__'], sketchOrientation=RIGHT, 
			sketchPlane=P2.datums[13], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			P2.datums[10])
		del M.sketches['__profile__']
		P2.DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=XYPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.66, name='__profile__', 
			sheetSize=26.6, transform=
			mdb.models['Model-1'].parts['Part-2'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[15], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-2'].datums[9], 
			sketchOrientation=RIGHT, origin=(SL/2.0, 0.0, 10.0)))
		mdb.models['Model-1'].parts['Part-2'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0.0, -SL/2.0), point2=(
			0.0, SL/2.0))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0.0, SL/2.0), point2=(
			-SL*sin(60*pi/180)/3.0, 0.0))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-SL*sin(60*pi/180)/3.0, 
			0.0), point2=(0.0, -SL/2.0))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(
			10, 10), point2=(-10, 
			-10))
		mdb.models['Model-1'].parts['Part-2'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[15], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-2'].datums[9])
		del mdb.models['Model-1'].sketches['__profile__']
		P2.DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=YZPLANE)
		M.ConstrainedSketch(gridSpacing=0.79, name='__profile__', 
			sheetSize=31.69, transform=
			P2.MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[17], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-2'].datums[11], 
			sketchOrientation=RIGHT, origin=(10.0, 0, 0.0)))
		P2.projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		M.sketches['__profile__'].rectangle(point1=(0.0, -0), 
			point2=(4, 4))
		P2.CutExtrude(flipExtrudeDirection=OFF, 
			sketch=M.sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[17], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			P2.datums[11])
		del M.sketches['__profile__']
		P2.DatumAxisByTwoPoint(point1=
			P2.datums[7], point2=
			P2.datums[8])		
		M.rootAssembly.DatumCsysByDefault(CARTESIAN)
		M.rootAssembly.Instance(dependent=ON, name='Part-1-1', 
			part=P)
		M.rootAssembly.Instance(dependent=ON, name='Part-2-1', 
			part=P2)
		M.rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, 1.0), 
			instanceList=('Part-1-1', 'Part-2-1'), number=3, point=(SL/2.0, SL*sin(60*pi/180)/3, ZH/2)
			, totalAngle=360.0)
		M.rootAssembly.InstanceFromBooleanMerge(domain=GEOMETRY, 
			instances=(M.rootAssembly.instances['Part-1-1'], 
			M.rootAssembly.instances['Part-2-1'], 
			M.rootAssembly.instances['Part-1-1-rad-2'], 
			M.rootAssembly.instances['Part-1-1-rad-3'], 
			M.rootAssembly.instances['Part-2-1-rad-2'], 
			M.rootAssembly.instances['Part-2-1-rad-3']), 
			keepIntersections=ON, name='Part-3', originalInstances=DELETE)
		# exit(99)
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#0 #40 ]', ), ), point1=mdb.models['Model-1'].parts['Part-3'].vertices[5]
			, point2=mdb.models['Model-1'].parts['Part-3'].vertices[15], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[12])
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#0 #40 ]', ), ), point1=
			mdb.models['Model-1'].parts['Part-3'].vertices[27], point2=
			mdb.models['Model-1'].parts['Part-3'].vertices[36], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[34])
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#2000 ]', ), ), point1=mdb.models['Model-1'].parts['Part-3'].vertices[52]
			, point2=mdb.models['Model-1'].parts['Part-3'].vertices[47], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[59])
		
		
		
		# mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			# mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			# '[#0 #20 ]', ), ), point1=
			# mdb.models['Model-1'].parts['Part-3'].vertices[27], point2=
			# mdb.models['Model-1'].parts['Part-3'].vertices[36], point3=
			# mdb.models['Model-1'].parts['Part-3'].vertices[34])
		# mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			# mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			# '[#1000 ]', ), ), point1=mdb.models['Model-1'].parts['Part-3'].vertices[54]
			# , point2=mdb.models['Model-1'].parts['Part-3'].vertices[49], point3=
			# mdb.models['Model-1'].parts['Part-3'].vertices[59])
		# mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			# mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			# '[#0 #100 ]', ), ), point1=
			# mdb.models['Model-1'].parts['Part-3'].vertices[17], point2=
			# mdb.models['Model-1'].parts['Part-3'].vertices[29], point3=
			# mdb.models['Model-1'].parts['Part-3'].vertices[26])	
		mdb.models['Model-1'].rootAssembly.regenerate()
		NTZ=NTZ-1
		for i in range(NTZ):
			a=M.rootAssembly.Instance(dependent=ON, name='Cell'+str(i),
			   part=mdb.models['Model-1'].parts['Part-3'])
			if i/2==i/2.0:
				N=1
				NN=0
			else: 
				N=0
				NN=1
			M.rootAssembly.rotate(angle=N*180.0, axisDirection=(-1.0, 0.0,
			  0), axisPoint=(SL/2.0, SL*sin(60*pi/180)/3, ZH), instanceList=('Cell'+str(i), ))
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('Cell'+str(i), ), vector=(
				0.0, 0.0, (i+NN)*ZH))
			M.rootAssembly.rotate(angle=N*180.0, axisDirection=(0.0, 0.0,
			  -1.0), axisPoint=(SL/2.0, SL*sin(60*pi/180)/3, ZH), instanceList=('Cell'+str(i), ))
		SingleInstances_List=[]	
		SingleInstances_List=M.rootAssembly.instances.keys()
		SingleInstances_Tuple=list(SingleInstances_List)
		print len(SingleInstances_List)
		print  SingleInstances_List[0]
		print NTZ
		if NTZ!=0 :
			mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Part-4', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
				for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
				nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
			M.rootAssembly.regenerate()
			PP4=mdb.models['Model-1'].parts['Part-4']
		else :
			mdb.models['Model-1'].Part(name='Part-4', objectToCopy=
				mdb.models['Model-1'].parts['Part-3'])
			# del mdb.models['Model-1'].rootAssembly.features['Part-4-1']
		# New for RadL
		N_rad=RadL/2
		P_rad=N_rad
		if RadL/2!=RadL/2.0: P_rad=N_rad+1
		for i in range (P_rad):
			M.rootAssembly.Instance(dependent=ON, name='PN'+str(i),
			   part=mdb.models['Model-1'].parts['Part-4'])
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('PN'+str(i), ), vector=(
					-SL/2.0, -SL*sin(60*pi/180), 0))
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('PN'+str(i), ), vector=(
					0, 2*i*-SL*sin(60*pi/180), 0))		
			
			mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, -sin(60*pi/180), 
				0.0), direction2=(0.5, -sin(60*pi/180), 0.0), instanceList=('PN'+str(i), ), number1=1, 
				number2=RadL-2*i, spacing1=SL/2.0, spacing2=SL)
			
			mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, sin(60*pi/180), 
				0.0), direction2=(-0.5, -sin(60*pi/180), 0.0), instanceList=('PN'+str(i), ), number1=1, 
				number2=RadL-2*i, spacing1=SL/2.0, spacing2=SL)
			# Insert Fliped part
		if RadL >1:
			for i in range (N_rad):
				M.rootAssembly.Instance(dependent=ON, name='PNFLP'+str(i),
				   part=mdb.models['Model-1'].parts['Part-4'])
				M.rootAssembly.rotate(angle=180.0, axisDirection=(0.0, 0.0,
				  -1.0), axisPoint=(0, 0, ZH), instanceList=('PNFLP'+str(i), ))
				mdb.models['Model-1'].rootAssembly.translate(instanceList=('PNFLP'+str(i), ), vector=(
						SL/2.0, (2*i+1)*-SL*sin(60*pi/180), 0))
				mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, -sin(60*pi/180), 
					0.0), direction2=(0.5, -sin(60*pi/180), 0.0), instanceList=('PNFLP'+str(i), ), number1=1, 
					number2=RadL-2*i-1, spacing1=SL/2.0, spacing2=SL)
				
				mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, sin(60*pi/180), 
					0.0), direction2=(-0.5, -sin(60*pi/180), 0.0), instanceList=('PNFLP'+str(i), ), number1=1, 
					number2=RadL-2*i-1, spacing1=SL/2.0, spacing2=SL)
			SingleInstances_List=[]	
			SingleInstances_List=M.rootAssembly.instances.keys()
			SingleInstances_Tuple=list(SingleInstances_List)
			print len(SingleInstances_List)
			print  SingleInstances_List[0]
			mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Tetr_Coll', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
				for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
				nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
			mdb.models['Model-1'].rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, -0.25)
					, instanceList=('Tetr_Coll-1', ), number=6, point=(0.0, 0.0, 0.125), 
					totalAngle=360.0)
		elif RadL==1:
			mdb.models['Model-1'].rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, -0.25)
				, instanceList=('PN0', ), number=6, point=(0.0, 0.0, 0.125), 
				totalAngle=360.0)
		SingleInstances_List=[]	
		SingleInstances_List=M.rootAssembly.instances.keys()
		SingleInstances_Tuple=list(SingleInstances_List)
		print len(SingleInstances_List)
		print  SingleInstances_List[0]
		mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Tetr_Final', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
			for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
			nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
		M.rootAssembly.regenerate()
		PP4=mdb.models['Model-1'].parts['Tetr_Final']
# ****************************************Tetra *******************************
	elif ComboBox1 == 'TETRA':
		print 'TETRA'
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-1', type=
			DEFORMABLE_BODY)
		SL
		M=mdb.models['Model-1']
		P=M.parts['Part-1']
		P.ReferencePoint(point=(0.0, 0.0, 0.0))
		P.DatumPointByCoordinate(coords=(SL, 0.0, 
			0.0))
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180), 0.0))
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 0.0, 
			0.0))
		P.DatumPointByMidPoint(point1=P.datums[3], point2=P.referencePoints[1])
		P.DatumPointByMidPoint(point1=P.datums[3], point2=P.datums[2])
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180)/3, 0.0))
		P.DatumPointByCoordinate(coords=(SL*cos(60*pi/180), 
			SL*sin(60*pi/180)/3, ZH))
		St_Length=sqrt(((SL*cos(60*pi/180))**2+(SL*sin(60*pi/180)/3)**2)+ZH**2)
		# print St_Length
		P.DatumAxisByTwoPoint(point1=
		 P.referencePoints[1], point2=
		 P.datums[2])
		P.DatumAxisByTwoPoint(point1=
		 P.referencePoints[1], point2=
		 P.datums[3])
		P.DatumAxisByTwoPoint(point1=
		 P.datums[2], point2=
		 P.datums[3])
		P.DatumAxisByTwoPoint(point1=
		 P.referencePoints[1], point2=
		 P.datums[8]) 
		P.DatumPlaneByPointNormal(normal=
			P.datums[12], point=
			P.referencePoints[1])
		M.ConstrainedSketch(gridSpacing=26.07, name='__profile__', 
			sheetSize=1043.02, transform=
			P.MakeSketchTransform(
			sketchPlane=P.datums[13], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=P.datums[9], 
			sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
		P.projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		M.sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(R, 0.0))
		P.SolidExtrude(depth=St_Length, 
			flipExtrudeDirection=OFF, sketch=
			M.sketches['__profile__'], sketchOrientation=RIGHT, 
			sketchPlane=P.datums[13], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			P.datums[9])
		del M.sketches['__profile__']	
	###### New Try
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=XYPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.81, name='__profile__', 
			sheetSize=32.44, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[15], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[12], 
			sketchOrientation=RIGHT, origin=(0, 0, 10.0)))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(
			0, 0), point2=(SL/4.0, 
			SL*sin(60*pi/180)/2))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(SL/4.0, 
			SL*sin(60*pi/180)/2), point2=(0, SL*sin(60*pi/180)*(2.0/3.0)))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(
			0, SL*sin(60*pi/180)*(2.0/3.0)), point2=(-SL/4.0, 
			SL*sin(60*pi/180)/2))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-SL/4.0, 
			SL*sin(60*pi/180)/2), point2=(0, 0))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(
			-10, -10), point2=(10, 10))
		mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[15], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[12])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=YZPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.91, name='__profile__', 
			sheetSize=36.52, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[17], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[11], 
			sketchOrientation=RIGHT, origin=(10.0, 0, 0)))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(0, 
			-0), point2=(5, 5))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(-ZH, 
			-SL), point2=(-10, 10))
		mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[17], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[11])
		del mdb.models['Model-1'].sketches['__profile__']
		# exit(999)
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[5])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[6], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[3])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#2 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].vertices[3], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-1'].datums[8])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#8 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].vertices[1], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[10], point3=
			mdb.models['Model-1'].parts['Part-1'].datums[8])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[12], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[3])
		
		mdb.models['Model-1'].parts['Part-1'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].datums[8], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[7])
		mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
		mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-1-1', 
			part=mdb.models['Model-1'].parts['Part-1'])
		mdb.models['Model-1'].rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, -1.0), 
			instanceList=('Part-1-1', ), number=3, point=(SL/2.0, SL*sin(60*pi/180)/3, ZH/2), 
			totalAngle=360.0)
		mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(domain=GEOMETRY, 
			instances=(mdb.models['Model-1'].rootAssembly.instances['Part-1-1'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-1-1-rad-2'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-1-1-rad-3']), 
			keepIntersections=ON, name='Part-2', originalInstances=DELETE)
		mdb.models['Model-1'].rootAssembly.regenerate()
		NTZ=NTZ-1
		for i in range(NTZ):
			a=M.rootAssembly.Instance(dependent=ON, name='Cell'+str(i),
			   part=mdb.models['Model-1'].parts['Part-2'])
			if i/2==i/2.0:
				N=1
				NN=0
			else: 
				N=0
				NN=1
			M.rootAssembly.rotate(angle=N*180.0, axisDirection=(-1.0, 0.0,
			  0), axisPoint=(SL/2.0, SL*sin(60*pi/180)/3, ZH), instanceList=('Cell'+str(i), ))
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('Cell'+str(i), ), vector=(
				0.0, 0.0, (i+NN)*ZH))
			M.rootAssembly.rotate(angle=N*180.0, axisDirection=(0.0, 0.0,
			  -1.0), axisPoint=(SL/2.0, SL*sin(60*pi/180)/3, ZH), instanceList=('Cell'+str(i), ))
		SingleInstances_List=[]	
		SingleInstances_List=M.rootAssembly.instances.keys()
		SingleInstances_Tuple=list(SingleInstances_List)
		print len(SingleInstances_List)
		print  SingleInstances_List[0]
		print NTZ
		if NTZ!=0 :
			mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Part-4', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
				for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
				nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
			M.rootAssembly.regenerate()
			PP4=mdb.models['Model-1'].parts['Part-4']
		else :
			mdb.models['Model-1'].Part(name='Part-4', objectToCopy=
				mdb.models['Model-1'].parts['Part-2'])
		# del mdb.models['Model-1'].rootAssembly.features['Part-4-1']
		# New for RadL
		N_rad=RadL/2
		P_rad=N_rad
		if RadL/2!=RadL/2.0: P_rad=N_rad+1
		for i in range (P_rad):
			M.rootAssembly.Instance(dependent=ON, name='PN'+str(i),
			   part=mdb.models['Model-1'].parts['Part-4'])
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('PN'+str(i), ), vector=(
					-SL/2.0, -SL*sin(60*pi/180), 0))
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('PN'+str(i), ), vector=(
					0, 2*i*-SL*sin(60*pi/180), 0))		
			
			mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, -sin(60*pi/180), 
				0.0), direction2=(0.5, -sin(60*pi/180), 0.0), instanceList=('PN'+str(i), ), number1=1, 
				number2=RadL-2*i, spacing1=SL/2.0, spacing2=SL)
			
			mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, sin(60*pi/180), 
				0.0), direction2=(-0.5, -sin(60*pi/180), 0.0), instanceList=('PN'+str(i), ), number1=1, 
				number2=RadL-2*i, spacing1=SL/2.0, spacing2=SL)
			# Insert Fliped part
		if RadL >1:
			for i in range (N_rad):
				M.rootAssembly.Instance(dependent=ON, name='PNFLP'+str(i),
				   part=mdb.models['Model-1'].parts['Part-4'])
				M.rootAssembly.rotate(angle=180.0, axisDirection=(0.0, 0.0,
				  -1.0), axisPoint=(0, 0, ZH), instanceList=('PNFLP'+str(i), ))
				mdb.models['Model-1'].rootAssembly.translate(instanceList=('PNFLP'+str(i), ), vector=(
						SL/2.0, (2*i+1)*-SL*sin(60*pi/180), 0))
						
				mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, -sin(60*pi/180), 
					0.0), direction2=(0.5, -sin(60*pi/180), 0.0), instanceList=('PNFLP'+str(i), ), number1=1, 
					number2=RadL-2*i-1, spacing1=SL/2.0, spacing2=SL)
				
				mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(5.0, sin(60*pi/180), 
					0.0), direction2=(-0.5, -sin(60*pi/180), 0.0), instanceList=('PNFLP'+str(i), ), number1=1, 
					number2=RadL-2*i-1, spacing1=SL/2.0, spacing2=SL)
			SingleInstances_List=[]	
			SingleInstances_List=M.rootAssembly.instances.keys()
			SingleInstances_Tuple=list(SingleInstances_List)
			print len(SingleInstances_List)
			print  SingleInstances_List[0]
			mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Tetr_Coll', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
				for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
				nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
			# M.rootAssembly.regenerate()
			mdb.models['Model-1'].rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, -0.25)
					, instanceList=('Tetr_Coll-1', ), number=6, point=(0.0, 0.0, 0.125), 
					totalAngle=360.0)
		elif RadL==1:
			mdb.models['Model-1'].rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, -0.25)
				, instanceList=('PN0', ), number=6, point=(0.0, 0.0, 0.125), 
				totalAngle=360.0)
		SingleInstances_List=[]	
		SingleInstances_List=M.rootAssembly.instances.keys()
		SingleInstances_Tuple=list(SingleInstances_List)
		print len(SingleInstances_List)
		print  SingleInstances_List[0]
		mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Tetr_Final', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
			for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
			nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
		M.rootAssembly.regenerate()
		PP4=mdb.models['Model-1'].parts['Tetr_Final']		
			# ############################## PYRAMIDAL
	elif ComboBox1 == 'PYRAMEDAL':
		print 'PYRAMEDAL'	
		SLP=Pyr_SL
		ZHP=Pyr_Z
		print SLP
		print ZHP
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-1', type=
			DEFORMABLE_BODY)
		mdb.models['Model-1'].parts['Part-1'].ReferencePoint(point=(0.0, 0.0, 0.0))
		mdb.models['Model-1'].parts['Part-1'].DatumPointByCoordinate(coords=(SLP, 0.0, 
			0.0))
		mdb.models['Model-1'].parts['Part-1'].DatumPointByCoordinate(coords=(SLP, SLP, 
			0.0))
		mdb.models['Model-1'].parts['Part-1'].DatumPointByCoordinate(coords=(0.0, SLP, 
			0.0))
		mdb.models['Model-1'].parts['Part-1'].DatumPointByCoordinate(coords=(float(SLP/2.0), float(SLP/2.0), 
			0.0))
		mdb.models['Model-1'].parts['Part-1'].DatumPointByCoordinate(coords=(float(SLP/2.0), float(SLP/2.0), 
			ZHP))
		mdb.models['Model-1'].parts['Part-1'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[2])
		mdb.models['Model-1'].parts['Part-1'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].datums[2], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[3])
		mdb.models['Model-1'].parts['Part-1'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[4])
		mdb.models['Model-1'].parts['Part-1'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].datums[4], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[3])
		mdb.models['Model-1'].parts['Part-1'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[6])
		mdb.models['Model-1'].parts['Part-1'].DatumPointByMidPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[2])
		mdb.models['Model-1'].parts['Part-1'].DatumPointByMidPoint(point1=
			mdb.models['Model-1'].parts['Part-1'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-1'].datums[4])
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPointNormal(normal=
			mdb.models['Model-1'].parts['Part-1'].datums[11], point=
			mdb.models['Model-1'].parts['Part-1'].referencePoints[1])
		SL_Lenght=sqrt(float(SLP/2.0)**2+float(SLP/2.0)**2+ZHP**2)
		print SL_Lenght
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=25.49, name='__profile__', 
			sheetSize=1019.9, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[14], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[7], 
			sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(R, 0.0))
		mdb.models['Model-1'].parts['Part-1'].SolidExtrude(depth=SL_Lenght, 
			flipExtrudeDirection=OFF, sketch=
			mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=RIGHT, 
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[14], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[7])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=XYPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.82, name='__profile__', 
			sheetSize=33.13, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[16], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[7], 
			sketchOrientation=RIGHT, origin=(float(SLP/4.0), float(SLP/4.0), 10.0)))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(float(SLP/4.0), float(SLP/4.0)), point2=
			(-float(SLP/4.0), float(SLP/4.0)))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-float(SLP/4.0), float(SLP/4.0)), 
			point2=(-float(SLP/4.0), -float(SLP/4.0)))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-float(SLP/4.0), -float(SLP/4.0)), 
			point2=(-SLP, -float(SLP/4.0)))  # cancel
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-SLP, 
			-float(SLP/4.0)), point2=(-SLP, SLP))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-SLP, 
			SLP), point2=(float(SLP/4.0), SLP))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(float(SLP/4.0), 
			SLP), point2=(float(SLP/4.0), float(SLP/4.0)))
		# Other 	
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(float(SLP/4.0), 
			-float(SLP/4.0)), point2=(float(SLP/4.0), 0))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(float(SLP/4.0), 
			0), point2=(float(SLP/2.0), -0))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(float(SLP/2.0), 
			0), point2=(float(SLP/2.0), -float(SLP/2.0)))	
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(float(SLP/2.0), -float(SLP/2.0)), 
			point2=(0, -float(SLP/2.0)))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0, -float(SLP/2.0)), 
			point2=(0, -float(SLP/4.0)))	
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0, -float(SLP/4.0)), 
			point2=(float(SLP/4.0), -float(SLP/4.0)))
		mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[16], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[7])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].parts['Part-1'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=YZPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.96, name='__profile__', 
			sheetSize=38.66, transform=
			mdb.models['Model-1'].parts['Part-1'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[18], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-1'].datums[8], 
			sketchOrientation=RIGHT, origin=(10.0, float(SLP/4.0), float(ZHP/2.0))))
		mdb.models['Model-1'].parts['Part-1'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(float(ZHP/2.0), -float(SLP/4.0)), 
			point2=(ZHP, float(SLP/6.0)))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(-float(ZHP/2.0), float(SLP/4.0)), 
			point2=(-ZHP, 0.0))
		mdb.models['Model-1'].parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-1'].datums[18], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-1'].datums[8])
		del mdb.models['Model-1'].sketches['__profile__']
		## ***************************Partioning***********************************
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[6], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[5])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[6], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[6], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[3])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#2 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].vertices[3], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-1'].datums[6])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#8 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].vertices[1], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[10], point3=
			mdb.models['Model-1'].parts['Part-1'].datums[6])
		mdb.models['Model-1'].parts['Part-1'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-1'].cells.getSequenceFromMask(('[#1 ]', 
			), ), point1=mdb.models['Model-1'].parts['Part-1'].datums[6], point2=
			mdb.models['Model-1'].parts['Part-1'].vertices[12], point3=
			mdb.models['Model-1'].parts['Part-1'].vertices[3])
		mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-2', type=
			DEFORMABLE_BODY)
		mdb.models['Model-1'].parts['Part-2'].ReferencePoint(point=(0.0, 0.0, 0.0))
		mdb.models['Model-1'].parts['Part-2'].DatumPointByCoordinate(coords=(SLP, 0.0, 
			0.0))
		mdb.models['Model-1'].parts['Part-2'].DatumPointByCoordinate(coords=(SLP, SLP, 
			0.0))
		mdb.models['Model-1'].parts['Part-2'].DatumPointByCoordinate(coords=(0.0, SLP, 
			0.0))
		mdb.models['Model-1'].parts['Part-2'].DatumPointByCoordinate(coords=(float(SLP/2.0), float(SLP/2.0), 
			0.0))
		mdb.models['Model-1'].parts['Part-2'].DatumPointByCoordinate(coords=(float(SLP/2.0), float(SLP/2.0), 
			ZHP))
		mdb.models['Model-1'].parts['Part-2'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[2])
		mdb.models['Model-1'].parts['Part-2'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].datums[2], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[3])
		mdb.models['Model-1'].parts['Part-2'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[4])
		mdb.models['Model-1'].parts['Part-2'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].datums[4], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[3])
		mdb.models['Model-1'].parts['Part-2'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[6])
		mdb.models['Model-1'].parts['Part-2'].DatumPointByMidPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[2])
		mdb.models['Model-1'].parts['Part-2'].DatumPointByMidPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[4])
		mdb.models['Model-1'].parts['Part-2'].DatumPlaneByPointNormal(normal=
			mdb.models['Model-1'].parts['Part-2'].datums[11], point=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1])
		mdb.models['Model-1'].parts['Part-2'].DatumPlaneByPointNormal(normal=
			mdb.models['Model-1'].parts['Part-2'].datums[7], point=
			mdb.models['Model-1'].parts['Part-2'].referencePoints[1])
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=25.49, name='__profile__', 
			sheetSize=1019.9, transform=
			mdb.models['Model-1'].parts['Part-2'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[15], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-2'].datums[9], 
			sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.0)))
		mdb.models['Model-1'].parts['Part-2'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].CircleByCenterPerimeter(center=(
			0.0, 0.0), point1=(R, 0.0))
		mdb.models['Model-1'].parts['Part-2'].SolidExtrude(depth=SLP, 
			flipExtrudeDirection=OFF, sketch=
			mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=RIGHT, 
			sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[15], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-2'].datums[9])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].parts['Part-2'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=XYPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=25.49, name='__profile__', 
			sheetSize=1019.9, transform=
			mdb.models['Model-1'].parts['Part-2'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[17], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-2'].datums[11], 
			sketchOrientation=RIGHT, origin=(float(SLP/2.0), 0.0, 10.0)))
		SLP45=float(SLP/2.0)*sin(45*pi/180)	
		mdb.models['Model-1'].parts['Part-2'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(SLP45, 
			SLP45), point2=(-SLP45, -SLP45))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(-SLP45, 
			-SLP45), point2=(SLP45, -SLP45))
		mdb.models['Model-1'].sketches['__profile__'].Line(point1=(SLP45, 
			-SLP45), point2=(SLP45, SLP45))
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(10, 10), 
			point2=(-10, -10))
		mdb.models['Model-1'].parts['Part-2'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[17], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-2'].datums[11])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].parts['Part-2'].DatumPlaneByPrincipalPlane(offset=10.0, 
			principalPlane=YZPLANE)
		mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.86, name='__profile__', 
			sheetSize=34.46, transform=
			mdb.models['Model-1'].parts['Part-2'].MakeSketchTransform(
			sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[19], 
			sketchPlaneSide=SIDE1, 
			sketchUpEdge=mdb.models['Model-1'].parts['Part-2'].datums[8], 
			sketchOrientation=RIGHT, origin=(10.0, R/2.0, 0.0)))
		mdb.models['Model-1'].parts['Part-2'].projectReferencesOntoSketch(filter=
			COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
		mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(0.0, -0.25), 
			point2=(2*R, 2*R))
		mdb.models['Model-1'].parts['Part-2'].CutExtrude(flipExtrudeDirection=OFF, 
			sketch=mdb.models['Model-1'].sketches['__profile__'], sketchOrientation=
			RIGHT, sketchPlane=mdb.models['Model-1'].parts['Part-2'].datums[19], 
			sketchPlaneSide=SIDE1, sketchUpEdge=
			mdb.models['Model-1'].parts['Part-2'].datums[8])
		del mdb.models['Model-1'].sketches['__profile__']
		mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
		mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-1-1', 
			part=mdb.models['Model-1'].parts['Part-1'])
		mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-2-1', 
			part=mdb.models['Model-1'].parts['Part-2'])
		mdb.models['Model-1'].parts['Part-2'].DatumAxisByTwoPoint(point1=
			mdb.models['Model-1'].parts['Part-2'].datums[6], point2=
			mdb.models['Model-1'].parts['Part-2'].datums[5])
		mdb.models['Model-1'].rootAssembly.regenerate()
		mdb.models['Model-1'].rootAssembly.RadialInstancePattern(axis=(0.0, 0.0, -1.0), 
			instanceList=('Part-1-1', 'Part-2-1'), number=4, point=(float(SLP/2.0), float(SLP/2.0), float(ZHP/2.0)), 
			totalAngle=360.0)
		mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(domain=GEOMETRY, 
			instances=(mdb.models['Model-1'].rootAssembly.instances['Part-1-1'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-2-1'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-1-1-rad-2'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-1-1-rad-3'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-1-1-rad-4'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-2-1-rad-2'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-2-1-rad-3'], 
			mdb.models['Model-1'].rootAssembly.instances['Part-2-1-rad-4']), 
			keepIntersections=ON, name='Part-3', originalInstances=DELETE)
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#0 #80000 ]', ), ), point1=
			mdb.models['Model-1'].parts['Part-3'].vertices[3], point2=
			mdb.models['Model-1'].parts['Part-3'].vertices[7], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[10])
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#40000 ]', ), ), point1=
			mdb.models['Model-1'].parts['Part-3'].vertices[70], point2=
			mdb.models['Model-1'].parts['Part-3'].vertices[65], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[79])
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#0 #80000 ]', ), ), point1=
			mdb.models['Model-1'].parts['Part-3'].vertices[55], point2=
			mdb.models['Model-1'].parts['Part-3'].vertices[61], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[64])
		mdb.models['Model-1'].parts['Part-3'].PartitionCellByPlaneThreePoints(cells=
			mdb.models['Model-1'].parts['Part-3'].cells.getSequenceFromMask((
			'[#0 #200000 ]', ), ), point1=
			mdb.models['Model-1'].parts['Part-3'].vertices[41], point2=
			mdb.models['Model-1'].parts['Part-3'].vertices[47], point3=
			mdb.models['Model-1'].parts['Part-3'].vertices[46])
#  ******************** For Flip roation and adjustments ***************************************	
		NPH=NPH-1
		for i in range(NPH):
			a=M.rootAssembly.Instance(dependent=ON, name='Cell'+str(i),
			   part=mdb.models['Model-1'].parts['Part-3'])
			if i/2==i/2.0:
				N=1
				NN=0
			else: 
				N=0
				NN=1
			M.rootAssembly.rotate(angle=N*180.0, axisDirection=(-1.0, 0.0,
			  0), axisPoint=(SLP/2.0, SLP/2.0, ZHP), instanceList=('Cell'+str(i), ))
			mdb.models['Model-1'].rootAssembly.translate(instanceList=('Cell'+str(i), ), vector=(
				0.0, 0.0, (i+NN)*ZHP))
		SingleInstances_List=[]	
		# exit(0)
		SingleInstances_List=M.rootAssembly.instances.keys()
		SingleInstances_Tuple=list(SingleInstances_List)
		print len(SingleInstances_List)
		print  SingleInstances_List[0]
	## Method2@@@@@@@@@@@@@@@@@@@@@
		print NPH
		if NPH!=0 :
			mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Part-4', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
				for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
				nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
			M.rootAssembly.regenerate()
			PP4=mdb.models['Model-1'].parts['Part-4']
		elif NPH==0 :
			mdb.models['Model-1'].Part(name='Part-4', objectToCopy=
				mdb.models['Model-1'].parts['Part-3'])
				
			mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-4-1', 
				part=mdb.models['Model-1'].parts['Part-4'])
		
		
		mdb.models['Model-1'].rootAssembly.LinearInstancePattern(direction1=(1.0, 0.0, 
			0.0), direction2=(0.0, 1.0, 0.0), instanceList=('Part-4-1', ), number1=NPX, 
			number2=NPY, spacing1=SLP, spacing2=SLP)
		SingleInstances_List=[]	
		SingleInstances_List=M.rootAssembly.instances.keys()
		SingleInstances_Tuple=list(SingleInstances_List)
		print len(SingleInstances_List)
		print  SingleInstances_List[0]
		mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Part-6', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
			for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
			nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
		M.rootAssembly.regenerate()
		PP4=mdb.models['Model-1'].parts['Part-6']
		XD=SLP*NPX/2.0
		YD=SLP*NPY/2.0
		ZD=(NPH+1)*ZHP
	
	if 	ComboBox1=='TETRA' or ComboBox1=='TETRAHEDRON':
		mdb.models['Model-1'].rootAssembly.regenerate()
		mdb.models['Model-1'].rootAssembly.translate(instanceList=('Tetr_Final-1', ), 
			vector=(RadL*SL, RadL*SL, 0.0))
		XD=RadL*SL
		YD=XD
		ZD=(NTZ+1)*ZH
		
	elif ComboBox1 == 'BCC' or ComboBox1 == 'BCCV' or ComboBox1 == 'BCCA':
		# For Array Only
		if NX==1 and NY==1 and NZ==1:
			PPAArt2=M.rootAssembly.Instance(dependent=ON, name='Cell',
				   part=P)
			PP4=P
		else:
		
			for i in range(NX):	
			  for j in range(NY):
				for k in range(NZ):
				  a=M.rootAssembly.Instance(dependent=ON, name='Cell'+str(i)+str(j)+str(k),
				   part=P)
				  a.translate(vector=((0.0+(i*X)), (0.0+(j*Y)), (0.0+(k*Z))))
			SingleInstances_List=M.rootAssembly.instances.keys()
			SingleInstances_Tuple=list(SingleInstances_List)
			print len(SingleInstances_List)
			print  SingleInstances_List[0]
			PPAArt2=mdb.models['Model-1'].rootAssembly.InstanceFromBooleanMerge(name='Part-2', instances=([M.rootAssembly.instances[SingleInstances_List[n]]
				for n in range(len(SingleInstances_List))] ), mergeNodes=ALL,                            
				nodeMergingTolerance=0.1, domain=GEOMETRY,keepIntersections=ON, originalInstances=DELETE)
			M.rootAssembly.regenerate()
			PP4=mdb.models['Model-1'].parts['Part-2']
		XD=X*float(NX)/2
		YD=Y*float(NY)/2
		ZD=Z*NZ
		# To draw the Rigid Plates **************************************************************
	mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
	mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(-XD, -YD), 
	 point2=(XD, YD))
	mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Part-3', type=
		DISCRETE_RIGID_SURFACE)
	mdb.models['Model-1'].parts['Part-3'].BaseShell(sketch=
		mdb.models['Model-1'].sketches['__profile__'])
	del mdb.models['Model-1'].sketches['__profile__']
	mdb.models['Model-1'].parts['Part-3'].ReferencePoint(point=(0.0, 0.0, 0.0))
	mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
	doorInstance=mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-3-1', 
		part=mdb.models['Model-1'].parts['Part-3'])
	mdb.models['Model-1'].rootAssembly.translate(instanceList=('Part-3-1', ), 
		vector=(XD, YD, -0.001))
	mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-3-2', 
		part=mdb.models['Model-1'].parts['Part-3'])
	mdb.models['Model-1'].rootAssembly.translate(instanceList=('Part-3-2', ), 
		vector=(XD, YD, ZD+0.001))
		# Mehing the Rigid Plates *************************************************
	mdb.models['Model-1'].parts['Part-3'].seedPart(deviationFactor=0.1, 
		minSizeFactor=0.1, size=0.5)
	mdb.models['Model-1'].parts['Part-3'].setElementType(elemTypes=(ElemType(
		elemCode=R3D4, elemLibrary=EXPLICIT), ElemType(elemCode=R3D3, 
		elemLibrary=EXPLICIT)), regions=(
	mdb.models['Model-1'].parts['Part-3'].faces.getSequenceFromMask(('[#1 ]', 
		), ), ))
	mdb.models['Model-1'].parts['Part-3'].generateMesh()
	# ***********************Setting the Step and Capturing the results ***************************
	mdb.models['Model-1'].ExplicitDynamicsStep(massScaling=((SEMI_AUTOMATIC, MODEL, 
	AT_BEGINNING, 0.0, 1e-07, BELOW_MIN, 0, 0, 0.0, 0.0, 0, None), ), name=
	'Step-1', nlgeom=OFF, previous='Initial', timePeriod=0.01)
	mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(variables=(
		'S', 'MISES', 'E', 'PE', 'PEEQ', 'LE', 'U', 'V', 'A', 'RF', 'DAMAGEC', 
		'DAMAGET', 'DAMAGEFC', 'DMICRT', 'STATUS'))
	mdb.models['Model-1'].rootAssembly.Set(name='RF_UP', referencePoints=(
		mdb.models['Model-1'].rootAssembly.instances['Part-3-1'].referencePoints[2], 
		))
	mdb.models['Model-1'].rootAssembly.Set(name='RF_Down', referencePoints=(
		mdb.models['Model-1'].rootAssembly.instances['Part-3-2'].referencePoints[2], 
		))
	mdb.models['Model-1'].HistoryOutputRequest(createStepName='Step-1', name=
		'H-Output-2', numIntervals=100, rebar=EXCLUDE, region=
		mdb.models['Model-1'].rootAssembly.sets['RF_Down'], sectionPoints=DEFAULT, 
		variables=('RF1', 'RF2', 'RF3', 'RM1', 'RM2', 'RM3', 'RT'))
	mdb.models['Model-1'].HistoryOutputRequest(createStepName='Step-1', name=
		'H-Output-3', numIntervals=100, rebar=EXCLUDE, region=
		mdb.models['Model-1'].rootAssembly.sets['RF_UP'], sectionPoints=DEFAULT, 
		variables=('RF1', 'RF2', 'RF3', 'RM1', 'RM2', 'RM3', 'RT'))
	# ********************** For the attraction and adding Tie ***********************************
	mdb.models['Model-1'].ContactProperty('IntProp-1')
	mdb.models['Model-1'].interactionProperties['IntProp-1'].TangentialBehavior(
		dependencies=0, directionality=ISOTROPIC, elasticSlipStiffness=None, 
		formulation=PENALTY, fraction=0.005, maximumElasticSlip=FRACTION, 
		pressureDependency=OFF, shearStressLimit=None, slipRateDependency=OFF, 
		table=((0.5, ), ), temperatureDependency=OFF)
	mdb.models['Model-1'].interactionProperties['IntProp-1'].NormalBehavior(
		allowSeparation=ON, constraintEnforcementMethod=DEFAULT, 
		pressureOverclosure=HARD)
	mdb.models['Model-1'].ContactExp(createStepName='Initial', name='Int-1')
	mdb.models['Model-1'].interactions['Int-1'].includedPairs.setValuesInStep(
		stepName='Initial', useAllstar=ON)
	mdb.models['Model-1'].interactions['Int-1'].contactPropertyAssignments.appendInStep(
		assignments=((GLOBAL, SELF, 'IntProp-1'), ), stepName='Initial')
	if ComboBox1 == 'BCC' or ComboBox1 == 'BCCV' or ComboBox1 == 'BCCA':
		SS1= doorInstance.faces.findAt(((7.5,7.5,-1.E-03),))
		mdb.models['Model-1'].rootAssembly.Surface(name='m_Surf-1', side1Faces=SS1)
		SumFace=''
		Po=[]
		Po.append((0.3,0.3,0))
		Po.append((0.3,0.45,0))
		Po.append((0.3,4.65,0))
		Po.append((0.3,5.65,0))
		xc=[]
		yc=[]
		R_bar=R/sin(54.73566797*pi/180)
		faces_tuple1= ()
		for j in range(NY):
			xc=array([float(R_bar/2)+X*j for k in range(NX*NY)])
			yc=array([float(float(R_bar/6)+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple1 +=  (tup,)
				i=i+1
		xc=[]
		yc=[]
		faces_tuple2= ()
		for j in range(NY):
			xc=array([float(R_bar/6)+X*j for k in range(NX*NY)])
			yc=array([float(R_bar/2+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple2 +=  (tup,)
				i=i+1
		xc=[]
		yc=[]
		faces_tuple3= ()
		for j in range(NY):
			xc=array([float(X-R_bar/6)+X*j for k in range(NX*NY)])
			yc=array([float(R_bar/2)+Y*k for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple3 +=  (tup,)
				i=i+1
		
		faces_tuple4= ()
		for j in range(NY):
			xc=array([X-R_bar/2+X*j for k in range(NX*NY)])
			yc=array([float(R_bar/6+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple5= ()
		for j in range(NY):
			xc=array([X-R_bar/2+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/6+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple6= ()
		for j in range(NY):
			xc=array([X-R_bar/6+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/2+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple7= ()
		for j in range(NY):
			xc=array([R_bar/6+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/2+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple8= ()
		for j in range(NY):
			xc=array([R_bar/2+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/6+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], 0])
				faces_tuple4 +=  (tup,)
				i=i+1
		faceRegion = PPAArt2.faces.findAt(coordinates=faces_tuple2+faces_tuple1+faces_tuple3+faces_tuple4+faces_tuple5+faces_tuple6+
			faces_tuple7+faces_tuple8)
		mySurface = M.rootAssembly.Surface(
			name='s_Surf-1', side1Faces=faceRegion)
		mdb.models['Model-1'].Tie(adjust=ON, master=
			mdb.models['Model-1'].rootAssembly.surfaces['m_Surf-1'], name=
			'Constraint-1', positionToleranceMethod=COMPUTED, slave=
			mdb.models['Model-1'].rootAssembly.surfaces['s_Surf-1'], thickness=ON, 
			tieRotations=ON)
		mdb.models['Model-1'].rootAssembly.Surface(name='m_Surf-3', side2Faces=
			mdb.models['Model-1'].rootAssembly.instances['Part-3-2'].faces.getSequenceFromMask(
			('[#1 ]', ), ))
		Z_Dpth=float(Z*NZ)
		xc=[]
		yc=[]
		faces_tuple1= ()
		for j in range(NY):
			xc=array([float(R_bar/2)+X*j for k in range(NX*NY)])
			yc=array([float(float(R_bar/6)+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple1 +=  (tup,)
				i=i+1
		print len(xc)
		print len(yc)
		xc=[]
		yc=[]
		faces_tuple2= ()
		for j in range(NY):
			xc=array([float(R_bar/6)+X*j for k in range(NX*NY)])
			yc=array([float(R_bar/2+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple2 +=  (tup,)
				i=i+1
		xc=[]
		yc=[]
		faces_tuple3= ()
		for j in range(NY):
			xc=array([float(X-R_bar/6)+X*j for k in range(NX*NY)])
			yc=array([float(R_bar/2)+Y*k for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple3 +=  (tup,)
				i=i+1
		
		faces_tuple4= ()
		for j in range(NY):
			xc=array([X-R_bar/2+X*j for k in range(NX*NY)])
			yc=array([float(R_bar/6+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple5= ()
		for j in range(NY):
			xc=array([X-R_bar/2+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/6+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple6= ()
		for j in range(NY):
			xc=array([X-R_bar/6+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/2+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple7= ()
		for j in range(NY):
			xc=array([R_bar/6+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/2+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple4 +=  (tup,)
				i=i+1
		faces_tuple8= ()
		for j in range(NY):
			xc=array([R_bar/2+X*j for k in range(NX*NY)])
			yc=array([float(Y-R_bar/6+Y*k) for k in range(NX*NY)])
			i=0
			while i<NY:  
				tup= tuple([xc[i], yc[i], Z_Dpth])
				faces_tuple4 +=  (tup,)
				i=i+1
		faceRegion = PPAArt2.faces.findAt(coordinates=faces_tuple2+faces_tuple1+faces_tuple3+faces_tuple4+faces_tuple5+faces_tuple6+
			faces_tuple7+faces_tuple8)
		mySurface = M.rootAssembly.Surface(
			name='s_Surf-3', side1Faces=faceRegion)	
		mdb.models['Model-1'].Tie(adjust=ON, master=
			mdb.models['Model-1'].rootAssembly.surfaces['m_Surf-3'], name=
			'Constraint-2', positionToleranceMethod=COMPUTED, slave=
			mdb.models['Model-1'].rootAssembly.surfaces['s_Surf-3'], thickness=ON, 
			tieRotations=ON)
		# Set the BOundary Conditions 	#########################################
	mdb.models['Model-1'].rootAssembly.Set(name='Set-3', referencePoints=(
		mdb.models['Model-1'].rootAssembly.instances['Part-3-2'].referencePoints[2], 
		))
	mdb.models['Model-1'].EncastreBC(createStepName='Initial', localCsys=None, 
		name='Fixed', region=mdb.models['Model-1'].rootAssembly.sets['Set-3'])
	mdb.models['Model-1'].SmoothStepAmplitude(data=((0.0, 0.0), (0.01, 1.0)), name=
		'Amp-1', timeSpan=STEP)
	mdb.models['Model-1'].rootAssembly.Set(name='Set-4', referencePoints=(
		mdb.models['Model-1'].rootAssembly.instances['Part-3-1'].referencePoints[2], 
		))
	FD=1	
	mdb.models['Model-1'].DisplacementBC(amplitude='Amp-1', createStepName='Step-1'
		, distributionType=UNIFORM, fieldName='', fixed=OFF, localCsys=None, name=
		'Movable_Plate', region=mdb.models['Model-1'].rootAssembly.sets['Set-4'], 
		u1=0.0, u2=0.0, u3=FD*0.5, ur1=0.0, ur2=0.0, ur3=0.0)	
		
	if Material=='Acrylonitrile butadiene styrene (ABS)':
		print 'Acrylonitrile butadiene styrene (ABS)'
		mdb.models['Model-1'].Material(name='ABS')
		mdb.models['Model-1'].materials['ABS'].Density(table=((7.92e-10, ), ))
		mdb.models['Model-1'].materials['ABS'].Elastic(table=((861.0, 0.35), ))
		mdb.models['Model-1'].materials['ABS'].Plastic(table=((25.77548896, 0.0), (
			25.79557414, 3.1e-05), (25.81674124, 6.15e-05), (25.84618533, 0.000107775), 
			(25.91487964, 0.00019261), (26.00361705, 0.00025031), (25.99517947, 
			0.000261773), (25.98324343, 0.000269797), (25.9813051, 0.00028126), (
			25.98235071, 0.000304185), (26.00012877, 0.000327492), (26.02485603, 
			0.00036226), (26.0618025, 0.000400465), (26.07080555, 0.00042759), (
			26.07448984, 0.000450512), (26.09554959, 0.000481456), (26.13552913, 
			0.000523859), (26.16905356, 0.000577719), (26.24345035, 0.000635396), (
			26.25496274, 0.000654876), (26.24869601, 0.000673973), (26.24919248, 
			0.000689251), (26.25949381, 0.00070873), (26.26640533, 0.000739283), (
			26.30775935, 0.000781675), (26.32904191, 0.000812609), (26.34115546, 
			0.000835522), (26.36338436, 0.000870273), (26.39304696, 0.00090884), (
			26.42599331, 0.000947407), (26.45223379, 0.000997426), (26.48377656, 
			0.001027971), (26.50041155, 0.001051261), (26.50864013, 0.001074169), (
			26.51637767, 0.00109364), (26.52481848, 0.001124182), (26.55457166, 
			0.00116274), (26.57300692, 0.001197479), (26.59278527, 0.001228018), (
			26.61375102, 0.001258938), (26.63950503, 0.00128604), (26.65311442, 
			0.001320393), (26.69272343, 0.001366577), (26.7100797, 0.001397492), (
			26.73544996, 0.001432223), (26.75266022, 0.001455122), (26.75913491, 
			0.001482219), (26.78374792, 0.001512749), (26.81048191, 0.001547476), (
			26.81737953, 0.00157457), (26.83943645, 0.001608913), (26.86902617, 
			0.001643637), (26.87125944, 0.001666531), (26.88404459, 0.001693621), (
			26.91009694, 0.001728342), (26.92466967, 0.001758865), (26.96784717, 
			0.001808844), (27.01349417, 0.001866832), (27.04820996, 0.00189735), (
			27.05212182, 0.00192062), (27.05407419, 0.001939693), (27.06931681, 
			0.001966776), (27.08034842, 0.001997292), (27.10583349, 0.002028188), (
			27.11239803, 0.002051073), (27.11803393, 0.002078153), (27.13624561, 
			0.002109047), (27.16257737, 0.002143371), (27.19560643, 0.002185704), (
			27.2247669, 0.002220408), (27.24467579, 0.002262737), (27.2711866, 
			0.002293243), (27.28822922, 0.00232413), (27.2998466, 0.002351203), (
			27.31617235, 0.002381707), (27.32947696, 0.002404965), (27.34280718, 
			0.002435467), (27.35177341, 0.002466349), (27.37336965, 0.002497231), (
			27.40025462, 0.00252773), (27.41035306, 0.00255861), (27.41803876, 
			0.002585295), (27.4379653, 0.002612361), (27.45782428, 0.00264705), (
			27.48770339, 0.002689361), (27.521253, 0.002735482), (27.56417199, 
			0.002789223), (27.57506234, 0.002819714), (27.58830998, 0.002842962), (
			27.58702661, 0.002862017), (27.58797348, 0.002877262), (27.59957657, 
			0.002896698), (27.604767, 0.002927566), (27.62522304, 0.002954241), (
			27.62676575, 0.002981297), (27.6538221, 0.003019402), (27.69291035, 
			0.00307732), (27.76945393, 0.003153903), (27.81890122, 0.003192383), (
			27.80807251, 0.003207622), (27.80051456, 0.003219432), (27.80096562, 
			0.003234671), (27.81248964, 0.003257529), (27.82032404, 0.003284576), (
			27.82353038, 0.003315433), (27.83595615, 0.003338288), (27.8565702, 
			0.003369143), (27.87608608, 0.003411424), (27.90029696, 0.003449513), (
			27.94819726, 0.003507405), (28.00447824, 0.003564914), (28.02517049, 
			0.003599189), (28.0278997, 0.003614803), (28.02825825, 0.003630035), (
			28.02505223, 0.003649076), (28.03867934, 0.003683729), (28.06310339, 
			0.003710765), (28.06728348, 0.003737419), (28.07951301, 0.003768262), (
			28.09908888, 0.00380291), (28.11823144, 0.003829562), (28.13355374, 
			0.003868016), (28.1488475, 0.003906469), (28.19052158, 0.003952534), (
			28.22741376, 0.003998596), (28.24099069, 0.00402905), (28.24777338, 
			0.004048463), (28.24395876, 0.004071303), (28.24231934, 0.004090715), (
			28.25566706, 0.00411736), (28.28205605, 0.004151996), (28.29922047, 
			0.004186632), (28.31413365, 0.004213274), (28.32433152, 0.004244101), (
			28.33724345, 0.004274547), (28.35408539, 0.004309179), (28.3985816, 
			0.004362836), (28.42795499, 0.004397464), (28.4343168, 0.0044241), (
			28.4319704, 0.004443506), (28.42889734, 0.004466336), (28.4488116, 
			0.004497156), (28.45780153, 0.004535584), (28.49358425, 0.004569826), (
			28.4823393, 0.004596838), (28.51472572, 0.004631458), (28.53548721, 
			0.004658088), (28.53627774, 0.00469651), (28.57452794, 0.004734931), (
			28.59323253, 0.004765742), (28.6080731, 0.004799976), (28.61217651, 
			0.004826982), (28.62110304, 0.004849803), (28.62713085, 0.004880611), (
			28.65784023, 0.004922828), (28.66732963, 0.00494945), (28.67888028, 
			0.004980255), (28.68891821, 0.005007256), (28.70402133, 0.005037679), (
			28.71937794, 0.005072284), (28.74090121, 0.005106887), (28.74920455, 
			0.005133505), (28.7584918, 0.005164304), (28.77991997, 0.005198904), (
			28.81104723, 0.005240727), (28.83878202, 0.005294715), (28.86527965, 
			0.005321327), (28.86474754, 0.005344517), (28.86619405, 0.005367327), (
			28.87225922, 0.005390136), (28.86450654, 0.005413324), (28.88566655, 
			0.005440314), (28.89795605, 0.005478325), (28.91684103, 0.005512915), (
			28.93373061, 0.005547503), (28.95460385, 0.00558171), (28.9758038, 
			0.005627698), (29.02051768, 0.005677484), (29.02966298, 0.005700666), (
			29.02663799, 0.005715867), (29.02240029, 0.005739048), (29.02286099, 
			0.005761849), (29.03494695, 0.005792628), (29.05123195, 0.005823027), (
			29.0604963, 0.005861405), (29.08077306, 0.005892182), (29.09535641, 
			0.005926757), (29.10730272, 0.005957152), (29.12779847, 0.005991725), (
			29.14297747, 0.006037694), (29.17708544, 0.006079861), (29.19117771, 
			0.006110252), (29.19684429, 0.006133424), (29.20125874, 0.006156215), (
			29.20328868, 0.006179386), (29.21265532, 0.006209773), (29.22356977, 
			0.006240539), (29.22486187, 0.006263708), (29.23709451, 0.006294093), (
			29.2450222, 0.006324856), (29.25273578, 0.006355239), (29.26916701, 
			0.006389798), (29.30749127, 0.006435749), (29.34178448, 0.006485494), (
			29.35471552, 0.006516252), (29.35479892, 0.006539035), (29.35601628, 
			0.006562197), (29.36160373, 0.006588775), (29.36484407, 0.00661953), (
			29.36807833, 0.006646487), (29.38737746, 0.00667686), (29.39735518, 
			0.006703815), (29.40129199, 0.006737982), (29.42984219, 0.006783917), (
			29.45395516, 0.006826053), (29.48620042, 0.006864392), (29.49861371, 
			0.00690273), (29.50828094, 0.006925504), (29.51483447, 0.006956248), (
			29.519677, 0.006986991), (29.5313931, 0.007009763), (29.53112037, 
			0.007036709), (29.54089927, 0.007063275), (29.53577593, 0.00708263), (
			29.53480334, 0.0071054), (29.53299733, 0.007136138), (29.55053674, 
			0.007170291), (29.57984864, 0.007212411), (29.61698801, 0.007265913), (
			29.64786188, 0.007311823), (29.65747232, 0.007342555), (29.6558973, 
			0.007361525), (29.65931149, 0.007380875), (29.65292202, 0.007415019), (
			29.66636707, 0.007441954), (29.66566451, 0.007468889), (29.67190026, 
			0.007495444), (29.68202337, 0.00752617), (29.68751808, 0.007552723), (
			29.69466838, 0.007583448), (29.72403069, 0.007633137), (29.75308333, 
			0.007690408), (29.81504698, 0.007743884), (29.81875915, 0.007767018), (
			29.81317472, 0.007797357), (29.82091234, 0.00782049), (29.81162695, 
			0.007839451), (29.80224939, 0.007858791), (29.82009905, 0.007889127), (
			29.8110045, 0.00791605), (29.81403378, 0.007935009), (29.81828159, 
			0.007965722), (29.83733669, 0.008000225), (29.84926436, 0.00803814), (
			29.86023996, 0.008076433), (29.9002296, 0.008122306), (29.92577826, 
			0.008160595), (29.92682419, 0.00818751), (29.91939931, 0.008206464), (
			29.91425331, 0.008225418), (29.91640429, 0.008256122), (29.92281511, 
			0.008283035), (29.92232847, 0.008309568), (29.93101931, 0.008344059), (
			29.9497652, 0.00838234), (29.97357732, 0.00842403), (30.00728229, 
			0.008477846), (30.03079944, 0.008515742), (30.03599094, 0.008542648), (
			30.03024927, 0.008561595), (30.03026134, 0.008580921), (30.0344403, 
			0.008607446), (30.03489921, 0.008638139), (30.04392464, 0.00866883), (
			30.05964425, 0.008702931), (30.0865429, 0.008748775), (30.08698545, 
			0.008775675), (30.08032283, 0.008802194), (30.09519339, 0.008832881), (
			30.10240889, 0.008863566), (30.10920941, 0.00889766), (30.13407985, 
			0.008939708), (30.14237043, 0.008966602), (30.13875387, 0.008996905), (
			30.15721205, 0.009027585), (30.15971005, 0.009058265), (30.17165786, 
			0.009096139), (30.19536144, 0.009138178), (30.19590309, 0.00916128), (
			30.19350525, 0.009184003), (30.18477407, 0.009207104), (30.18280691, 
			0.009229825), (30.16634324, 0.009249138), (30.19618207, 0.009287005), (
			30.20447747, 0.009332823), (30.25345723, 0.009394162), (30.29342683, 
			0.009443761), (30.29274574, 0.009466477), (30.28431225, 0.009485786), (
			30.2741902, 0.009504715), (30.26480176, 0.009523644), (30.26255521, 
			0.009554309), (30.27470003, 0.009584972), (30.26060358, 0.009607685), (
			30.26242871, 0.009630776), (30.2769852, 0.009664844), (30.28486443, 
			0.009703074), (30.31242155, 0.009752657), (30.36910385, 0.009813592), (
			30.38732138, 0.009848032), (30.38652713, 0.009874902), (30.37626729, 
			0.009893824), (30.37184472, 0.00991653), (30.37668349, 0.009947182), (
			30.38071198, 0.009970266), (30.37385872, 0.009989186), (30.3571215, 
			0.01001189), (30.3671993, 0.010042539), (30.36966522, 0.010069404), (
			30.37078648, 0.010099673), (30.39080176, 0.010145453), (30.43260849, 
			0.010202581), (30.47206757, 0.010263867), (30.50403945, 0.010302075), (
			30.49665388, 0.010324771), (30.48191227, 0.010343685), (30.45677705, 
			0.010355411), (30.45649455, 0.010374324), (30.45351081, 0.01040118), (
			30.45570563, 0.010423874), (30.44306694, 0.010442786), (30.43510971, 
			0.01046964), (30.45757875, 0.010507839), (30.48058765, 0.010553601), (
			30.53386468, 0.010641336), (30.61266041, 0.010713561), (30.60813231, 
			0.010724905), (30.57224955, 0.010732468), (30.55339238, 0.010740408), (
			30.52810945, 0.010763095), (30.53307374, 0.010786159), (30.52687188, 
			0.010808845), (30.52814552, 0.010831908), (30.52640407, 0.010858374), (
			30.5389644, 0.010896558), (30.54515221, 0.010938522), (30.59068881, 
			0.011003165), (30.62945789, 0.011064024), (30.66494701, 0.011094641), (
			30.64269139, 0.01110598), (30.63314838, 0.011125257), (30.62209576, 
			0.011155494), (30.62318862, 0.011182329), (30.62337017, 0.011212564), (
			30.63403811, 0.011243177), (30.64203817, 0.011270009), (30.63769947, 
			0.011296463), (30.63715752, 0.011327073), (30.65504192, 0.01136524), (
			30.66124487, 0.01139547), (30.65397138, 0.011422298), (30.6755478, 
			0.011456683), (30.67372178, 0.01148691), (30.67618725, 0.011528849), (
			30.69491875, 0.01156323), (30.69752687, 0.011585898), (30.69728713, 
			0.011616499), (30.6992792, 0.011647099), (30.70482853, 0.011673543), (
			30.70673346, 0.011704141), (30.7187576, 0.011734361), (30.70608858, 
			0.011757403), (30.7026085, 0.011783844), (30.71649185, 0.01182577), (
			30.74571689, 0.011871472), (30.77557347, 0.011920948), (30.77541233, 
			0.011947762), (30.76696534, 0.011970422), (30.76359393, 0.011997235), (
			30.76586733, 0.012023669), (30.76308545, 0.012054257), (30.7611152, 
			0.012084844), (30.77556173, 0.012115052), (30.76950263, 0.012138085), (
			30.76077187, 0.012164516), (30.77429392, 0.012198875), (30.78609417, 
			0.012233233), (30.78541206, 0.012271365), (30.81405021, 0.012312893), (
			30.8152537, 0.012347247), (30.8280266, 0.012385375), (30.84230665, 
			0.012415952), (30.83165869, 0.012442375), (30.83639352, 0.012469176), (
			30.84102026, 0.012495598), (30.82441493, 0.012514848), (30.8178489, 
			0.012541269), (30.81940076, 0.01257184), (30.82734404, 0.012602034), (
			30.82824893, 0.012643926), (30.86036542, 0.01268959), (30.87502966, 
			0.012731479), (30.90282386, 0.012780912), (30.90751329, 0.012807703), (
			30.9028234, 0.012830343), (30.87812411, 0.012849587), (30.87450805, 
			0.012872226), (30.87211176, 0.012895241), (30.87088475, 0.012925425), (
			30.87931843, 0.012952213), (30.87890486, 0.012978622), (30.87311282, 
			0.013012953), (30.89296055, 0.013054828), (30.90703894, 0.013096701), (
			30.94050074, 0.013153661), (30.9598761, 0.013187986), (30.95109872, 
			0.013210617), (30.94208239, 0.013229853), (30.93180468, 0.01324494), (
			30.91590281, 0.01326757), (30.914736, 0.01329812), (30.92708589, 
			0.01333244), (30.9292102, 0.013358839), (30.93324197, 0.013393157), (
			30.92815472, 0.013419932), (30.93494744, 0.013453871), (30.96607718, 
			0.01351081), (31.00789359, 0.013571894), (31.03147952, 0.013602057), (
			31.0074773, 0.013617516), (30.99116254, 0.013628827), (30.97214451, 
			0.013647678), (30.97145498, 0.013678216), (30.97126354, 0.013704606), (
			30.97668477, 0.013735142), (30.98518691, 0.013773217), (30.99412401, 
			0.013803751), (30.99133835, 0.013833908), (31.01336543, 0.013879518), (
			31.01741091, 0.013910049), (31.01967319, 0.013940202), (31.02707591, 
			0.013985807), (31.05047992, 0.014020103), (31.0486767, 0.01405063), (
			31.05088103, 0.014073242), (31.0405283, 0.014092461), (31.02800546, 
			0.014118841), (31.03045673, 0.014153133), (31.03531484, 0.01417951), (
			31.03943017, 0.0142138), (31.04166007, 0.014251857), (31.04381548, 
			0.014278232), (31.05069292, 0.014308751), (31.0690677, 0.014350571), (
			31.09346342, 0.014399925), (31.10026842, 0.014437975), (31.10612584, 
			0.01445681), (31.08895822, 0.014476023), (31.07899867, 0.014506159), (
			31.09310057, 0.014536671), (31.08510044, 0.014563038), (31.08596124, 
			0.014593548), (31.08726752, 0.014620291), (31.08161104, 0.014646656), (
			31.07803178, 0.014673398), (31.08552627, 0.014715203), (31.09841743, 
			0.014749098), (31.11935135, 0.0147909), (31.13330273, 0.014828935), (
			31.13372932, 0.014855671), (31.12813928, 0.01488203), (31.13281108, 
			0.014908765), (31.1268743, 0.014938888), (31.13503938, 0.014973152), (
			31.14900306, 0.015007415), (31.14345386, 0.01503377), (31.14003058, 
			0.015064266), (31.1392782, 0.01509062), (31.13592187, 0.015117349), (
			31.14275933, 0.015155371), (31.17826396, 0.015212214), (31.20694007, 
			0.015253997), (31.22734547, 0.015303306), (31.23264857, 0.015325889), (
			31.22292852, 0.015345085), (31.19159933, 0.015363903), (31.19004544, 
			0.015383098), (31.17557517, 0.01540568), (31.17578916, 0.015439928), (
			31.18655719, 0.015470035), (31.18213908, 0.015492991), (31.18133145, 
			0.015519333), (31.1828169, 0.015553577), (31.18755318, 0.015595346), (
			31.23250845, 0.015655926), (31.2619761, 0.015701453), (31.26078039, 
			0.015720641), (31.24345387, 0.015739453), (31.22699901, 0.015758264), (
			31.2230559, 0.015777452), (31.22311391, 0.015807548), (31.22009524, 
			0.015838021), (31.22506523, 0.015868492), (31.2288971, 0.015902348), (
			31.23730673, 0.01594034), (31.2575316, 0.015989615), (31.28924179, 
			0.016035127), (31.28004608, 0.016054309), (31.27443066, 0.016073114), (
			31.25900485, 0.016096057), (31.24895305, 0.016122383), (31.25328501, 
			0.016156606), (31.26059802, 0.016194589), (31.28784372, 0.016232195), (
			31.27768013, 0.016266414), (31.28594399, 0.016296872), (31.27266912, 
			0.016319433), (31.27084333, 0.01634989), (31.28832454, 0.016384106), (
			31.28132094, 0.016410424), (31.29095766, 0.016444638), (31.30180745, 
			0.01647885), (31.2928423, 0.016508926), (31.30019565, 0.016543136), (
			31.31333108, 0.016581104), (31.31589445, 0.016607418), (31.31319359, 
			0.016634107), (31.30909461, 0.016660419), (31.30398391, 0.016683348), (
			31.29679322, 0.016713418), (31.30856969, 0.016747621), (31.30241167, 
			0.016774306), (31.30865059, 0.016812265), (31.35538938, 0.016869014), (
			31.37122475, 0.016910727), (31.37838618, 0.01694079), (31.3694069, 
			0.016959955), (31.34832957, 0.016982501), (31.34762915, 0.01700918), (
			31.34924401, 0.01703924), (31.33711527, 0.017065917), (31.34571407, 
			0.017092218), (31.3429078, 0.017122651), (31.34767993, 0.017149326), (
			31.35410439, 0.017186896), (31.37146941, 0.017232353), (31.39277003, 
			0.017270295), (31.39380391, 0.017308235), (31.39215617, 0.017338662), (
			31.39968803, 0.017368712), (31.39908986, 0.017399136), (31.3938883, 
			0.017425428), (31.39218695, 0.017452096), (31.39556269, 0.017478762), (
			31.38817098, 0.017501296), (31.37498714, 0.01752383), (31.37865375, 
			0.01755425), (31.37931687, 0.017588425), (31.39012861, 0.017618467), (
			31.40434964, 0.017663904), (31.43933404, 0.017713095), (31.44897255, 
			0.017762283), (31.46353519, 0.017800205), (31.45802266, 0.017819353), (
			31.46018842, 0.017841879), (31.44354131, 0.017864781), (31.42904647, 
			0.017883553), (31.42848488, 0.017910207), (31.43402953, 0.017943994), (
			31.42243647, 0.017970647), (31.41227914, 0.017989417), (31.41810828, 
			0.018023576), (31.44289358, 0.018080256), (31.48509547, 0.018136933), (
			31.49795178, 0.018171087), (31.49314806, 0.018197734), (31.48946118, 
			0.018220253), (31.48456381, 0.018239017), (31.45283783, 0.01826191), (
			31.46974553, 0.018284427), (31.46973024, 0.018314823), (31.45811239, 
			0.018337714), (31.44526025, 0.018367734), (31.4590249, 0.018409385), (
			31.50363335, 0.018466043), (31.55417066, 0.018534329), (31.57176843, 
			0.018564343), (31.54738875, 0.018579725), (31.54581844, 0.018594731), (
			31.50595258, 0.018613489), (31.49391513, 0.018640124), (31.51241361, 
			0.018674261), (31.51303766, 0.018708022), (31.51498811, 0.018734655), (
			31.52242761, 0.018765039), (31.51945441, 0.018802547), (31.52720449, 
			0.018829178), (31.5270651, 0.018863309), (31.53613118, 0.018900814), (
			31.5463326, 0.018938692), (31.55160486, 0.018972819), (31.55268525, 
			0.01899532), (31.54967017, 0.019025695), (31.55368513, 0.01905607), (
			31.54900423, 0.019082318), (31.5455484, 0.019108941), (31.5475762, 
			0.019138938), (31.56166353, 0.019173058), (31.56079942, 0.019203428), (
			31.55289382, 0.019229673), (31.54414035, 0.019256292), (31.55776108, 
			0.019290408), (31.57273173, 0.019339519), (31.59275898, 0.019373257), (
			31.59321995, 0.019399872), (31.57388849, 0.01942986), (31.57559516, 
			0.019456474), (31.57952616, 0.019486835), (31.59899904, 0.019532188), (
			31.60275481, 0.01956592), (31.59144575, 0.019588782), (31.58384522, 
			0.019611269), (31.58494725, 0.01963413), (31.57121993, 0.019656616), (
			31.58436925, 0.019698214), (31.60269347, 0.019732315), (31.60496945, 
			0.019770162), (31.61475799, 0.019803886), (31.60796764, 0.01983049), (
			31.61667708, 0.019864587), (31.63429682, 0.019909922), (31.63018517, 
			0.019936149), (31.62385945, 0.019955256), (31.60875349, 0.019973988), (
			31.59722112, 0.019996466), (31.59242897, 0.020019319), (31.60558299, 
			0.020060901), (31.63419351, 0.02011372), (31.65537057, 0.020147807), (
			31.65496561, 0.020181518), (31.66549184, 0.020215603), (31.66355989, 
			0.020253432), (31.67521616, 0.020287514), (31.6724203, 0.02031373), (
			31.66439795, 0.020336575), (31.65624749, 0.020359045), (31.64858329, 
			0.02037777), (31.635366, 0.020404359), (31.64021425, 0.020434691), (
			31.63998412, 0.020464648), (31.65503432, 0.020498723), (31.67324959, 
			0.02054403), (31.68935438, 0.020596823), (31.72926599, 0.020645869), (
			31.722758, 0.020664589), (31.70513798, 0.020687426), (31.69232287, 
			0.020709888), (31.69293063, 0.020732724), (31.68070838, 0.020755185), (
			31.67113514, 0.020781764), (31.66878449, 0.020804224), (31.66563609, 
			0.020830801), (31.66593299, 0.020864863), (31.68844226, 0.020917639), (
			31.72322201, 0.02096667), (31.75822413, 0.021023183), (31.76424049, 
			0.021053497), (31.74917443, 0.021068466), (31.72342535, 0.021087178), (
			31.71539384, 0.021102521), (31.71296407, 0.021124974), (31.70600305, 
			0.021155284), (31.70798746, 0.021188962), (31.70390307, 0.021215528), (
			31.70005589, 0.02125332), (31.72241073, 0.021291109), (31.72958724, 
			0.021321041), (31.72747616, 0.021355087), (31.74505915, 0.021389131), (
			31.74709927, 0.021430657), (31.77452172, 0.021468066), (31.77764054, 
			0.021494625), (31.75644282, 0.02152081), (31.76696003, 0.021551109), (
			31.75422482, 0.021573925), (31.75241854, 0.021596368), (31.75068746, 
			0.021626664), (31.75094606, 0.021660326), (31.7494163, 0.02168688), (
			31.74144602, 0.021717174), (31.75909058, 0.021750832), (31.78050402, 
			0.021796082), (31.81553545, 0.021852548), (31.82164456, 0.021879098), (
			31.80099091, 0.021897794), (31.78454666, 0.021913125), (31.77457702, 
			0.021935559), (31.76414329, 0.021965845), (31.78742588, 0.022011086), (
			31.79419665, 0.022037257), (31.78290642, 0.022056324), (31.76409759, 
			0.022082494), (31.77118457, 0.022112776), (31.7900149, 0.022154271), (
			31.82115091, 0.022210717), (31.8587032, 0.022259685), (31.84989166, 
			0.022274636), (31.82507819, 0.022289961), (31.80482913, 0.022308649), (
			31.80351558, 0.022342662), (31.82396623, 0.022387885), (31.84312019, 
			0.022421521), (31.83176151, 0.022444318), (31.83436552, 0.022474588), (
			31.82960713, 0.022497011), (31.81440883, 0.022523543), (31.8180884, 
			0.022557174), (31.82694831, 0.022591178), (31.84330067, 0.022640127), (
			31.89851591, 0.022704018), (31.92411603, 0.022749225), (31.91052294, 
			0.022768278), (31.89139367, 0.022779486), (31.86897379, 0.022798165), (
			31.8575625, 0.02282469), (31.85622683, 0.02285084), (31.84731529, 
			0.022873627), (31.83367024, 0.02289604), (31.83193687, 0.022926297), (
			31.84203836, 0.022956553), (31.84518259, 0.02299017), (31.85337559, 
			0.023035364), (31.8845938, 0.023080556), (31.91110161, 0.023125746), (
			31.90043767, 0.023148527), (31.88818658, 0.023167199), (31.88945344, 
			0.023197448), (31.89233384, 0.023227323), (31.88508189, 0.023250101), (
			31.87954831, 0.02327624), (31.88119578, 0.023302751), (31.87264599, 
			0.023332996), (31.88265742, 0.023370334), (31.9061759, 0.023411777), (
			31.90500438, 0.023449486), (31.93459496, 0.023483459), (31.92790032, 
			0.023509592), (31.91480829, 0.023532364), (31.91602735, 0.023566335), (
			31.92902379, 0.023599931), (31.93222996, 0.023633899), (31.94138772, 
			0.023671599), (31.94120561, 0.023697727), (31.93521169, 0.023720495), (
			31.92028548, 0.023742889), (31.92045714, 0.02377312), (31.91918153, 
			0.023803351), (31.93221187, 0.023844403), (31.95431594, 0.023885827), (
			31.9642272, 0.023919786), (31.97542254, 0.023961206), (31.9912919, 
			0.023991431), (31.98450668, 0.024021282), (31.97676408, 0.024047773), (
			31.96503999, 0.024066429), (31.95736114, 0.024089189), (31.94587446, 
			0.024115306), (31.94530924, 0.024134333), (31.93009958, 0.024156718), (
			31.92401895, 0.024186937), (31.94289856, 0.024228346), (31.96565177, 
			0.024277215), (32.01155437, 0.024344732), (32.03681126, 0.024382405), (
			32.0211192, 0.024401054), (32.00196492, 0.024420076), (31.99193831, 
			0.024438725), (31.98184667, 0.024461103), (31.98139494, 0.024491313), (
			31.96880025, 0.024517792), (31.96539481, 0.024543898), (31.97115989, 
			0.024577834), (31.97908853, 0.024611769), (31.98716165, 0.024645331), (
			32.01610954, 0.024702009), (32.04501154, 0.024747126), (32.04632771, 
			0.024773226), (32.03270433, 0.024791868), (32.01427596, 0.024810882), (
			32.01710981, 0.024836981), (32.02102019, 0.024878363), (32.02090755, 
			0.024901104), (32.01591527, 0.0249272), (32.01828199, 0.024957395), (
			32.01419017, 0.024979762), (32.01178559, 0.025006228), (32.01642044, 
			0.025047604), (32.04269654, 0.025092705), (32.06709547, 0.025141531), (
			32.07412263, 0.025179174), (32.07429932, 0.025201536), (32.06719342, 
			0.025227997), (32.05706346, 0.02524663), (32.04431954, 0.025269363), (
			32.03084135, 0.025295449), (32.0387447, 0.025321907), (32.03759328, 
			0.025351718), (32.03532525, 0.025378175), (32.04651732, 0.025419535), (
			32.06499086, 0.025460893), (32.0945758, 0.025513427), (32.11538593, 
			0.025554782), (32.11514354, 0.025577135), (32.10701372, 0.02559986), (
			32.09248881, 0.025618487), (32.07598192, 0.025648662), (32.09495512, 
			0.025682188), (32.10287269, 0.025712361), (32.09483656, 0.025734711), (
			32.09338277, 0.025764882), (32.08754826, 0.025795052), (32.0918196, 
			0.025824849), (32.10099947, 0.025869915), (32.13716518, 0.025922428), (
			32.16296822, 0.02596749), (32.16593587, 0.02599393), (32.14688142, 
			0.026019997), (32.14720273, 0.02605016), (32.15457291, 0.026076598), (
			32.13134599, 0.026098939), (32.13107536, 0.026121652), (32.12754005, 
			0.026147716), (32.11356063, 0.026170429), (32.11416204, 0.026196491), (
			32.11679877, 0.026230371), (32.12260536, 0.026264251), (32.12114792, 
			0.026294034), (32.1432586, 0.026335356), (32.15141076, 0.026369232), (
			32.15931063, 0.026410551), (32.15728694, 0.026440329), (32.15227524, 
			0.026459313), (32.14358993, 0.026485368), (32.13968305, 0.026515516), (
			32.15657657, 0.026553108), (32.15997685, 0.026582882), (32.1577258, 
			0.026609306), (32.14140108, 0.026627914), (32.13401782, 0.026650615), (
			32.12545663, 0.026680387), (32.15002105, 0.026725415), (32.17738699, 
			0.026777882), (32.22116217, 0.026830719), (32.22553471, 0.026856764), (
			32.20510977, 0.026879461), (32.20089871, 0.026898064), (32.18900724, 
			0.026920387), (32.18058454, 0.026946802), (32.18574703, 0.026980657), (
			32.18266781, 0.027002978), (32.17334777, 0.027029391), (32.17874595, 
			0.027063243), (32.18500488, 0.027093002), (32.18794228, 0.027134292), (
			32.22042572, 0.027186738), (32.25556519, 0.027231743), (32.25469243, 
			0.027261869), (32.24886223, 0.027280465), (32.22998825, 0.027303151), (
			32.22591936, 0.027329184), (32.2227549, 0.027359307), (32.2122237, 
			0.02738162), (32.20571803, 0.027404304), (32.20368881, 0.027430335), (
			32.20086877, 0.027460455), (32.20472808, 0.027494292), (32.21687073, 
			0.027539283), (32.24849792, 0.02758799), (32.28303301, 0.027644131), (
			32.28596361, 0.027670155), (32.26541157, 0.027689115), (32.25556025, 
			0.027703985), (32.23646656, 0.027722573), (32.2216687, 0.027745249), (
			32.22429978, 0.02777536), (32.2328711, 0.027805098), (32.21828913, 
			0.027827772), (32.2168322, 0.027861226), (32.23173735, 0.027902484), (
			32.25548497, 0.027947456), (32.29223684, 0.028011381), (32.32819359, 
			0.028056348), (32.3135444, 0.028071213), (32.28767096, 0.028082362), (
			32.26220427, 0.028097226), (32.25434506, 0.028116178), (32.24379749, 
			0.028145906), (32.24994649, 0.028176005), (32.24035357, 0.028202387), (
			32.2435905, 0.028232112), (32.26449595, 0.028273354), (32.28331195, 
			0.02831831), (32.30019493, 0.028366979), (32.3180228, 0.028400786), (
			32.31003076, 0.028430506), (32.31828359, 0.028456881), (32.31291837, 
			0.028475455), (32.28567537, 0.028494399), (32.27998811, 0.028520401), (
			32.28205735, 0.028546774), (32.26538892, 0.028572775), (32.28302771, 
			0.028610289), (32.3060653, 0.02865523), (32.31745567, 0.028696455), (
			32.32593802, 0.028726537), (32.31726176, 0.028752533), (32.30812473, 
			0.028778899), (32.3191476, 0.028812692), (32.33343913, 0.0288424), (
			32.33294232, 0.028879904), (32.33805489, 0.028913693), (32.33628941, 
			0.028935971), (32.32846751, 0.028962333), (32.33804153, 0.028992036), (
			32.33306329, 0.029018396), (32.31584978, 0.029044756), (32.31447769, 
			0.029074456), (32.32433384, 0.029108239), (32.32829595, 0.029142021), (
			32.34774196, 0.029179143), (32.36055305, 0.029216634), (32.374499, 
			0.029261548), (32.38256333, 0.029291613), (32.36959433, 0.029317594), (
			32.3721576, 0.029343946), (32.36396752, 0.029369926), (32.3548242, 
			0.029392565), (32.34771994, 0.029422626), (32.35483017, 0.029456026), (
			32.34963161, 0.029482374), (32.35202876, 0.029512061), (32.35266964, 
			0.02954583), (32.36131468, 0.029572175), (32.35393315, 0.029605571), (
			32.37142329, 0.029646756), (32.38835223, 0.02968423), (32.40627787, 
			0.029725413), (32.4103436, 0.029755464), (32.40056269, 0.029777723), (
			32.39272516, 0.029804063), (32.39020037, 0.029830031), (32.37761651, 
			0.02985266), (32.37685069, 0.029874917), (32.37805057, 0.029904963), (
			32.36710916, 0.029930929), (32.36954946, 0.029960974), (32.3804512, 
			0.030005854), (32.42730894, 0.030072985), (32.52177765, 0.030155316), (
			32.51769175, 0.03017015), (32.48207696, 0.030177938), (32.44435386, 
			0.030185354), (32.42508363, 0.030200188), (32.39427619, 0.030218729), (
			32.4018639, 0.030245057), (32.4122151, 0.030282509), (32.41677995, 
			0.030308464), (32.40670127, 0.03033479), (32.41367544, 0.03036853), (
			32.41513257, 0.030405606), (32.45334281, 0.030469374), (32.50124843, 
			0.030517938), (32.49038615, 0.030532767), (32.46500637, 0.030551673), (
			32.45448841, 0.030570207), (32.44684738, 0.030592449), (32.43689804, 
			0.030622474), (32.4369279, 0.030652498), (32.44252833, 0.03068215), (
			32.44007479, 0.030712173), (32.44596412, 0.030742194), (32.44910663, 
			0.030779256), (32.48517782, 0.030831512), (32.50711643, 0.030876353), (
			32.51173499, 0.030902664), (32.49794243, 0.030921192), (32.47544183, 
			0.03094009), (32.46089278, 0.030966029), (32.46826239, 0.030996043), (
			32.47611518, 0.031026056), (32.47311713, 0.031055697), (32.47242847, 
			0.031089413), (32.47217609, 0.031115348), (32.48169775, 0.031152767), (
			32.49882231, 0.031193889), (32.49415934, 0.031220191), (32.50443531, 
			0.031249827), (32.50617744, 0.031290945), (32.50306205, 0.031320949), (
			32.51336378, 0.031354656), (32.52645239, 0.031384288), (32.51734156, 
			0.031410585), (32.51644118, 0.031440215), (32.51269061, 0.031462808), (
			32.49231619, 0.031485029), (32.49097122, 0.031511324), (32.50117564, 
			0.031545025), (32.50279116, 0.031578354), (32.50842395, 0.031612053), (
			32.53148613, 0.031660562), (32.5610549, 0.031705365), (32.56720972, 
			0.031735357), (32.55740057, 0.031757572), (32.54101749, 0.031780158), (
			32.53334092, 0.031809777), (32.54782547, 0.031836063), (32.52847185, 
			0.031861978), (32.5365872, 0.031891965), (32.53197945, 0.031918249), (
			32.52430993, 0.031944163), (32.53811109, 0.03198155), (32.54995292, 
			0.032022638), (32.55684237, 0.032060023), (32.57935761, 0.032100738), (
			32.59184781, 0.032134419), (32.58749569, 0.032160697), (32.57634351, 
			0.032186603), (32.57673405, 0.032209179), (32.5650975, 0.032235085), (
			32.56658841, 0.032268761), (32.57691704, 0.032295035), (32.55858844, 
			0.032317238), (32.56018305, 0.032343511), (32.55780374, 0.032376814), (
			32.56307492, 0.032410485), (32.59030974, 0.032458956), (32.6283145, 
			0.032522222), (32.65498726, 0.032563288), (32.64002867, 0.032578456), (
			32.61103991, 0.032593254), (32.59426077, 0.032608052), (32.58465489, 
			0.032634317), (32.58944692, 0.032660212), (32.58124095, 0.032682776), (
			32.57530351, 0.032712369), (32.56931193, 0.03274233), (32.57423718, 
			0.03277599), (32.58469871, 0.032820744), (32.62472242, 0.032872892), (
			32.64152928, 0.032910246), (32.63328882, 0.032932435), (32.62500988, 
			0.032951295), (32.62330756, 0.03298088), (32.63294063, 0.033021927), (
			32.63764859, 0.033048181), (32.62333389, 0.033070367), (32.62227649, 
			0.033096621), (32.61073423, 0.033118806), (32.60255557, 0.033145058), (
			32.59517537, 0.033174636), (32.62794874, 0.033219373), (32.64826959, 
			0.033275197), (32.69283054, 0.033319929), (32.69103633, 0.033353569), (
			32.6815621, 0.033376118), (32.66967127, 0.033394601), (32.65408477, 
			0.033413083), (32.64864206, 0.033443023), (32.66066769, 0.033480355), (
			32.66084411, 0.033509924), (32.65618701, 0.033536166), (32.65851794, 
			0.033566102), (32.66371284, 0.033595669), (32.6641614, 0.033632995), (
			32.67627547, 0.033666624), (32.67290028, 0.033700252), (32.68996995, 
			0.033729815), (32.68290688, 0.033759745), (32.6844126, 0.033785611), (
			32.68798479, 0.03382293), (32.69817349, 0.033852858), (32.6920037, 
			0.033878721), (32.6860839, 0.033908648), (32.68836656, 0.033938573), (
			32.68600738, 0.03396074), (32.67562697, 0.03398697), (32.66169634, 
			0.034012829), (32.66538164, 0.034042752), (32.67013192, 0.034083755), (
			32.71028731, 0.034139532), (32.73555778, 0.034176838), (32.73361582, 
			0.034202693), (32.71098058, 0.034221529), (32.69956671, 0.034243689), (
			32.69255803, 0.034273605), (32.70059181, 0.03430315), (32.69516267, 
			0.034333064), (32.69961133, 0.034362977), (32.69640591, 0.03439252), (
			32.70118247, 0.034426124), (32.71900861, 0.034470804), (32.73433496, 
			0.034500713), (32.73315473, 0.034530251), (32.74411587, 0.03456385), (
			32.7268548, 0.034589695), (32.72853353, 0.034615908), (32.72621702, 
			0.034645813), (32.73616723, 0.034679039), (32.7258383, 0.03470525), (
			32.73166482, 0.034735152), (32.72745469, 0.0347573), (32.70796447, 
			0.034783509), (32.71794335, 0.034816731), (32.73601897, 0.034854011), (
			32.74493395, 0.0348876), (32.76288563, 0.034928568), (32.76218346, 
			0.034961785), (32.76862479, 0.03499537), (32.76924906, 0.035025263), (
			32.76541548, 0.035051096), (32.76497742, 0.035077297), (32.76662039, 
			0.035107188), (32.75954979, 0.035129328), (32.74633222, 0.035151468), (
			32.73174546, 0.035177667), (32.74454079, 0.035211244), (32.75542325, 
			0.035244452), (32.77945238, 0.035292785), (32.80263785, 0.035337426), (
			32.8216624, 0.035385755), (32.82261752, 0.035408258), (32.80398133, 
			0.035423014), (32.78507978, 0.035441828), (32.76880036, 0.035463961), (
			32.75604683, 0.035486463), (32.76207867, 0.035512284), (32.76343188, 
			0.035553227), (32.78073271, 0.035583103), (32.77748664, 0.035616298), (
			32.79636364, 0.035664613), (32.83094732, 0.035712926), (32.84497005, 
			0.035750173), (32.83959143, 0.035772669), (32.82250339, 0.035791107), (
			32.80996302, 0.035813601), (32.79466898, 0.035835726), (32.7927338, 
			0.035858219), (32.78480014, 0.035891405), (32.80132819, 0.035924959), (
			32.79947782, 0.035958511), (32.8057759, 0.035991694), (32.81871278, 
			0.03602893), (32.8226968, 0.036062479), (32.83037116, 0.03609234), (
			32.82727848, 0.036121832), (32.82970828, 0.036155378), (32.83324439, 
			0.036185236), (32.84186551, 0.036211039), (32.82422889, 0.036233524), (
			32.81507369, 0.036263011), (32.82035615, 0.036296552), (32.81921556, 
			0.036326407), (32.82118226, 0.036355891), (32.82877425, 0.036389429), (
			32.82861027, 0.036415227), (32.8249531, 0.036445078), (32.83287171, 
			0.036482298), (32.84642976, 0.036519516), (32.87437357, 0.036567788), (
			32.88985114, 0.03660095), (32.88235705, 0.036627111), (32.85948721, 
			0.036645533), (32.85283477, 0.036668008), (32.85208649, 0.036693799), (
			32.84849132, 0.036731009), (32.86789728, 0.036764535), (32.85209363, 
			0.036786639), (32.84275267, 0.03680911), (32.85245517, 0.036842633), (
			32.85119648, 0.036875786), (32.86808206, 0.036916674), (32.87520005, 
			0.036950193), (32.89052744, 0.036983711), (32.89514286, 0.037009493), (
			32.87604776, 0.037035643), (32.87521901, 0.037061424), (32.8666569, 
			0.037098621), (32.88203549, 0.037132134), (32.89271904, 0.037161595), (
			32.88962557, 0.037191423), (32.87859511, 0.037213886), (32.86687758, 
			0.03723598), (32.86903067, 0.037269488), (32.87214967, 0.037298945), (
			32.87209082, 0.037332452), (32.89165827, 0.037384366), (32.94685415, 
			0.03744364), (32.96421076, 0.03747346), (32.92855561, 0.037488186), (
			32.90398117, 0.037503279), (32.90079073, 0.037529048), (32.89764607, 
			0.037558866), (32.88777225, 0.037584633), (32.88770624, 0.037607087), (
			32.87709122, 0.037633221), (32.87701348, 0.037658987), (32.8682643, 
			0.0376888), (32.89081881, 0.037737016), (32.94690286, 0.03780363), (
			32.9712948, 0.037844479), (32.95910191, 0.037859199), (32.93428721, 
			0.037874287), (32.91902032, 0.037896367), (32.90904672, 0.037922493), (
			32.90702483, 0.037948251), (32.89584915, 0.037974377), (32.91200485, 
			0.03800786), (32.90775021, 0.038033616), (32.89393549, 0.038063419), (
			32.91358051, 0.038107937), (32.93896511, 0.038152453), (32.94756967, 
			0.038189241), (32.96113742, 0.038219039), (32.96040025, 0.038245157), (
			32.95035957, 0.038270907), (32.95486582, 0.038300702), (32.94188456, 
			0.038322773), (32.92863922, 0.038348888), (32.93563539, 0.038378313), (
			32.93231434, 0.038404427), (32.9261582, 0.038434219), (32.93333493, 
			0.038467319), (32.94046345, 0.038504464), (32.95113267, 0.038545285), (
			32.98578905, 0.038586104), (32.98220541, 0.038619567), (32.98456663, 
			0.038648985), (32.98126352, 0.038671415), (32.95820056, 0.038693476), (
			32.96495798, 0.038719582), (32.94965948, 0.03874532), (32.94465064, 
			0.038771424), (32.9464999, 0.038808558), (32.97932691, 0.038849366), (
			32.96397686, 0.038875101), (32.95850289, 0.038904878), (32.98281919, 
			0.038942007), (32.98716241, 0.038982442), (33.00519528, 0.039019568), (
			32.99728419, 0.039041989), (32.99059147, 0.039064043), (32.97888616, 
			0.039090139), (32.97700037, 0.039112192), (32.96527284, 0.039138287), (
			32.96335882, 0.039175407), (32.98102254, 0.039212158), (32.97882317, 
			0.03923825), (32.98165269, 0.039268017), (32.98256013, 0.03929374), (
			32.98083851, 0.039323505), (32.99066116, 0.039367967), (33.02889453, 
			0.039427124), (33.04629686, 0.039460559), (33.03868306, 0.039475255), (
			33.00675126, 0.039489951), (32.99230844, 0.039516037), (32.99906182, 
			0.039545427), (32.9995758, 0.039575185), (32.99497155, 0.039601268), (
			32.99957038, 0.03963433), (33.00313904, 0.039667758), (33.00091722, 
			0.039693838), (33.00335092, 0.039726897), (33.03142531, 0.039767668), (
			33.03221891, 0.039797419), (33.03994918, 0.039838187), (33.04153703, 
			0.039867568), (33.04190674, 0.039904661), (33.04865357, 0.039930735), (
			33.03206374, 0.03995277), (33.03091811, 0.039982515), (33.04515212, 
			0.040011892), (33.03458946, 0.040037963), (33.02810088, 0.040064034), (
			33.0265447, 0.040089737), (33.01954053, 0.040119478), (33.02387675, 
			0.04015289), (33.06128286, 0.040212001), (33.09274566, 0.040256423), (
			33.09090199, 0.040282121), (33.0764454, 0.040304515), (33.0673668, 
			0.040326541), (33.06597192, 0.040352604), (33.07097151, 0.04038197), (
			33.04785944, 0.040404362), (33.03752535, 0.040426385), (33.04245901, 
			0.040459787), (33.05099381, 0.040493187), (33.05757716, 0.040526587), (
			33.07607551, 0.040570628), (33.09667376, 0.040611365), (33.10946498, 
			0.0406521), (33.11220017, 0.040681824), (33.10483246, 0.040707511), (
			33.10861437, 0.040740904), (33.10698103, 0.040770626), (33.10001309, 
			0.04079998), (33.11292706, 0.0408297), (33.10945781, 0.040852081), (
			33.08714812, 0.040870426), (33.0810206, 0.040896108), (33.07197875, 
			0.040918488), (33.05791838, 0.0409405), (33.05599409, 0.040970216), (
			33.06873763, 0.041010936), (33.08438351, 0.041047987), (33.10623078, 
			0.041099708), (33.13643384, 0.041136755), (33.12079078, 0.041162431), (
			33.11518228, 0.041184805), (33.10642191, 0.041206811), (33.09874115, 
			0.041229184), (33.09424836, 0.041262192), (33.09251279, 0.041288231), (
			33.08777613, 0.041310235), (33.08761296, 0.04133994), (33.08568145, 
			0.041373311), (33.1039643, 0.041414015), (33.14697383, 0.041476718), (
			33.1848117, 0.041521084), (33.1682743, 0.041543083), (33.14821711, 
			0.041554449), (33.13458297, 0.041569115), (33.10753716, 0.041591113), (
			33.12036357, 0.041624476), (33.11220133, 0.041650505), (33.10391763, 
			0.041676167), (33.11513114, 0.041705861), (33.11470381, 0.041742886), (
			33.13222604, 0.041783575), (33.16277728, 0.041838924), (33.18269848, 
			0.041871912), (33.17187733, 0.041897935), (33.16116988, 0.041916261), (
			33.15457834, 0.041938618), (33.14829493, 0.041964272), (33.14911136, 
			0.041997623), (33.14616855, 0.042023643), (33.14690099, 0.04205296), (
			33.1520543, 0.042089972), (33.15353539, 0.042115989), (33.15692677, 
			0.042145304), (33.16126312, 0.042182312), (33.17945258, 0.042222983), (
			33.19761575, 0.042267316), (33.21481893, 0.04230432), (33.20830654, 
			0.042329966), (33.18683106, 0.042344986), (33.17293829, 0.042366967), (
			33.1605148, 0.042389314), (33.16451601, 0.04241862), (33.16243327, 
			0.042451956), (33.15358339, 0.042477597), (33.14820615, 0.042503605), (
			33.16594254, 0.042544263), (33.18124486, 0.042581256), (33.19332922, 
			0.042621911), (33.23181921, 0.042669889), (33.22876447, 0.042699187), (
			33.21275343, 0.042714202), (33.19172662, 0.042728851), (33.17424702, 
			0.042747161), (33.16513854, 0.042773162), (33.16857052, 0.042810147), (
			33.17607356, 0.042843103), (33.18326132, 0.042872762), (33.2020411, 
			0.042913405), (33.21491683, 0.042954047), (33.23014221, 0.042998347), (
			33.2350805, 0.043023975), (33.22587331, 0.043049968), (33.22182664, 
			0.043075594), (33.21823897, 0.043094265), (33.1939648, 0.043116229), (
			33.18941304, 0.043149541), (33.21168648, 0.043186512), (33.22017208, 
			0.043215796), (33.20931712, 0.043249104), (33.22392904, 0.043278752), (
			33.21327541, 0.043300712), (33.1988603, 0.043334018), (33.21821165, 
			0.043367322), (33.21180925, 0.043392941), (33.21185943, 0.043426243), (
			33.22260515, 0.043466864), (33.24679465, 0.043507483), (33.25847877, 
			0.043544075), (33.24970325, 0.043570054), (33.25383018, 0.043596033), (
			33.24251956, 0.043625304), (33.24582707, 0.043647623), (33.22677772, 
			0.043673234), (33.22117565, 0.04369921), (33.22048841, 0.04372482), (
			33.20884462, 0.043747137), (33.22012803, 0.043780062), (33.23308739, 
			0.043824326), (33.25922315, 0.043872246), (33.28779319, 0.043912848), (
			33.28151197, 0.043938819), (33.2746113, 0.043968445), (33.26887505, 
			0.043994048), (33.25829712, 0.044016359), (33.24838566, 0.044038303), (
			33.23988478, 0.04406427), (33.23280488, 0.044086213), (33.22329631, 
			0.044112178), (33.22015612, 0.044145092), (33.24062151, 0.044178369), (
			33.24107035, 0.044215302), (33.2649186, 0.044259547), (33.28893738, 
			0.04430379), (33.30007888, 0.044336697), (33.31579497, 0.044366312), (
			33.29230032, 0.044388615), (33.27850913, 0.044410551), (33.26358224, 
			0.044432852), (33.25838097, 0.044454787), (33.24873283, 0.044476722), (
			33.24044596, 0.044502677), (33.24006202, 0.044532287), (33.23862772, 
			0.044561531), (33.26056645, 0.044609416), (33.3091485, 0.044672284), (
			33.40891649, 0.044757077), (33.40374056, 0.044771696), (33.35699289, 
			0.04478266), (33.33017438, 0.044793623), (33.3044462, 0.044804953), (
			33.28177605, 0.044823225), (33.27500778, 0.044852826), (33.2829643, 
			0.04488206), (33.28508727, 0.044908005), (33.27034972, 0.044933584), (
			33.27727393, 0.044970489), (33.28410831, 0.045007393), (33.31682479, 
			0.045062564), (33.3806048, 0.045117732), (33.37235235, 0.045140017), (
			33.35197323, 0.04515463), (33.32703757, 0.045172896), (33.31269533, 
			0.045191528), (33.31752336, 0.045228423), (33.31740549, 0.045253994), (
			33.2995654, 0.045276276), (33.29483073, 0.045305498), (33.31224115, 
			0.045338738), (33.31473964, 0.045375628), (33.3328599, 0.045423474), (
			33.35741154, 0.045460361), (33.34965708, 0.045485926), (33.33113565, 
			0.045508203), (33.32555534, 0.045530115), (33.32221344, 0.045559694)))
		mdb.models['Model-1'].materials['ABS'].DuctileDamageInitiation(table=((0.04849, 
			0.0, 0.016), (0.05856, 0.005368108, 0.016), (0.07548, 0.01022973, 0.016), (
			0.07625, 0.012132973, 0.016), (0.08, 0.039579459, 0.016), (0.08148, 
			0.063874595, 0.016), (0.08218, 0.100517838, 0.016), (0.08243, 0.116105405, 
			0.016), (0.08247, 0.119156757, 0.016), (0.08252, 0.122176216, 0.016), (
			0.08257, 0.129007568, 0.016), (0.0826, 0.146187027, 0.016), (0.08263, 
			0.162915676, 0.016), (0.08268, 0.176302162, 0.016), (0.08271, 0.194018378, 
			0.016), (0.08275, 0.219813514, 0.016)))
		mdb.models['Model-1'].materials['ABS'].ductileDamageInitiation.DamageEvolution(
			table=((0.04, ), ), type=DISPLACEMENT)
		mdb.models['Model-1'].materials['ABS'].ShearDamageInitiation(table=((0.04849, 
			2.055555556, 0.016), (0.05856, 2.058865889, 0.016), (0.07548, 2.061863889, 
			0.016), (0.07625, 2.063037556, 0.016), (0.08, 2.079962889, 0.016), (
			0.08148, 2.094944889, 0.016), (0.08218, 2.117541556, 0.016), (0.08243, 
			2.127153889, 0.016), (0.08247, 2.129035556, 0.016), (0.08252, 2.130897556, 
			0.016), (0.08257, 2.135110222, 0.016), (0.0826, 2.145704222, 0.016), (
			0.08263, 2.156020222, 0.016), (0.08268, 2.164275222, 0.016), (0.08271, 
			2.175200222, 0.016), (0.08275, 2.191107222, 0.016)))
		mdb.models['Model-1'].materials['ABS'].shearDamageInitiation.DamageEvolution(
			table=((0.04, ), ), type=DISPLACEMENT)
		mdb.models['Model-1'].HomogeneousSolidSection(material='ABS', name=
			'ABS_Section', thickness=None)
		PP4.Set(cells=
			PP4.cells.getByBoundingBox(-50,-50,-50,50,50,50), name='Set-2')
		PP4.SectionAssignment(offset=0.0, 
			offsetField='', offsetType=MIDDLE_SURFACE, region=
			PP4.sets['Set-2'], sectionName=
			'ABS_Section', thicknessAssignment=FROM_SECTION)
	elif Material=='Inconel 625 (Not stated)':
		print '***********************Wrong! This Material is NOT availible currently**********'
	elif Material=='Titanume Alloy (Ti-6AL-4V)':
		print 'Titanume Alloy (Ti-6AL-4V)'
		mdb.models['Model-1'].Material(name='Ti-6Al-4V')
		mdb.models['Model-1'].materials['Ti-6Al-4V'].Elastic(table=((104000.0, 0.35), 
			))
		mdb.models['Model-1'].materials['Ti-6Al-4V'].Plastic(table=((
			915.30261031580562, 0.0), (923.7823056199893, 0.0025252525252525255), (
			931.85801905960648, 0.0050505050505050509), (939.56732324251197, 
			0.007575757575757576), (946.94222001986213, 0.010101010101010102), (
			954.01024940939988, 0.012626262626262628), (960.79533093400812, 
			0.015151515151515152), (967.31841174419037, 0.01767676767676768), (
			973.59797277657708, 0.020202020202020204), (979.65042896276395, 
			0.022727272727272728), (985.49044924186023, 0.025252525252525256), (
			991.13121508641893, 0.02777777777777778), (996.58463133120267, 
			0.030303030303030304), (1001.8614996023828, 0.032828282828282832), (
			1006.9716621304102, 0.035353535353535359), (1011.9241218949944, 
			0.03787878787878788), (1016.727143695219, 0.040404040404040407), (
			1021.3883397250941, 0.042929292929292935), (1025.9147424701796, 
			0.045454545454545456), (1030.3128671578584, 0.047979797979797983), (
			1034.588765545182, 0.050505050505050511), (1038.74807248004, 
			0.053030303030303032), (1042.7960463990044, 0.055555555555555559), (
			1046.7376047105238, 0.058080808080808087), (1050.5773548417164, 
			0.060606060606060608), (1054.3196215908474, 0.063131313131313135), (
			1057.9684713180679, 0.065656565656565663), (1061.5277334184284, 
			0.068181818181818191), (1065.0010194491229, 0.070707070707070718), (
			1068.3917402239981, 0.073232323232323232), (1071.7031211399244, 
			0.07575757575757576), (1074.9382159596228, 0.078282828282828287), (
			1078.0999192423401, 0.080808080808080815), (1081.1909775861038, 
			0.083333333333333343), (1084.2139998221296, 0.08585858585858587), (
			1087.1714662824977, 0.088383838383838398), (1090.0657372458018, 
			0.090909090909090912), (1092.8990606515781, 0.093434343434343439), (
			1095.6735791625142, 0.095959595959595967), (1098.3913366433767, 
			0.098484848484848495), (1101.0542841169772, 0.10101010101010102), (
			1103.66428525012, 0.10353535353535355), (1106.2231214161125, 
			0.10606060606060606), (1108.7324963749286, 0.10858585858585859), (
			1111.1940406073743, 0.11111111111111112), (1113.6093153354736, 
			0.11363636363636365), (1115.9798162577099, 0.11616161616161617), (
			1118.3069770246273, 0.1186868686868687), (1120.5921724775621, 
			0.12121212121212122), (1122.8367216708666, 0.12373737373737374), (
			1125.0418906958882, 0.12626262626262627), (1127.2088953231034, 
			0.12878787878787881), (1129.3389034771717, 0.13131313131313133), (
			1131.4330375582181, 0.13383838383838384), (1133.4923766213763, 
			0.13636363636363638), (1135.5179584254747, 0.1388888888888889), (
			1137.5107813607419, 0.14141414141414144), (1139.471806264492, 
			0.14393939393939395), (1141.4019581329464, 0.14646464646464646), (
			1143.3021277366342, 0.14898989898989901), (1145.1731731461432, 
			0.15151515151515152), (1147.0159211744349, 0.15404040404040406), (
			1148.8311687413941, 0.15656565656565657), (1150.6196841658264, 
			0.15909090909090912), (1152.3822083896789, 0.16161616161616163), (
			1154.1194561388829, 0.16414141414141414), (1155.8321170248655, 
			0.16666666666666669), (1157.5208565904618, 0.1691919191919192), (
			1159.1863173036711, 0.17171717171717174), (1160.8291195024444, 
			0.17424242424242425), (1162.4498622934486, 0.1767676767676768), (
			1164.0491244075351, 0.17929292929292931), (1165.6274650144526, 
			0.18181818181818182), (1167.1854244991482, 0.18434343434343436), (
			1168.7235252018522, 0.18686868686868688), (1170.2422721239761, 
			0.18939393939393942), (1171.7421536017237, 0.19191919191919193), (
			1173.2236419491826, 0.19444444444444445), (1174.6871940725512, 
			0.19696969696969699), (1176.133252057039, 0.1994949494949495), (
			1177.5622437278892, 0.20202020202020204), (1178.9745831868722, 
			0.20454545454545456), (1180.3706713255201, 0.2070707070707071), (
			1181.7508963162827, 0.20959595959595961), (1183.1156340827322, 
			0.21212121212121213), (1184.465248749852, 0.21464646464646467), (
			1185.8000930754038, 0.21717171717171718), (1187.1205088632948, 
			0.21969696969696972), (1188.4268273598195, 0.22222222222222224), (
			1189.7193696336005, 0.22474747474747478), (1190.998446939999, 
			0.22727272727272729), (1192.2643610707344, 0.22979797979797981), (
			1193.5174046893969, 0.23232323232323235), (1194.7578616535106, 
			0.23484848484848486), (1195.9860073237644, 0.2373737373737374), (
			1197.2021088609936, 0.23989898989898992), (1198.4064255114668, 
			0.24242424242424243), (1199.5992088810019, 0.24494949494949497), (
			1200.7807031984069, 0.24747474747474749), (1201.9511455687166, 0.25)))
		mdb.models['Model-1'].materials['Ti-6Al-4V'].Expansion(table=((8.6e-06, ), ))
		mdb.models['Model-1'].materials['Ti-6Al-4V'].Density(table=((4.429e-09, ), ))
		mdb.models['Model-1'].HomogeneousSolidSection(material='Ti-6Al-4V', name=
			'Ti-6Al-4V', thickness=None)
		mdb.models['Model-1'].HomogeneousSolidSection(material='Ti-6Al-4V', name=
			'Ti-6Al-4V', thickness=None)
		PP4.Set(cells=
			PP4.cells.getByBoundingBox(-50,-50,-50,50,50,50), name='Set-2')
		PP4.SectionAssignment(offset=0.0, 
			offsetField='', offsetType=MIDDLE_SURFACE, region=
			PP4.sets['Set-2'], sectionName=
			'Ti-6Al-4V', thicknessAssignment=FROM_SECTION)
			
	elif Material=='Other Material (Need to be defiened)':		
		print Mat_Name
		mdb.models['Model-1'].Material(name=Mat_Name)
		mdb.models['Model-1'].materials[Mat_Name].Elastic(table=((Young, Poiss), 
			))
		mdb.models['Model-1'].materials[Mat_Name].Plastic(table=((Table)))
		mdb.models['Model-1'].materials[Mat_Name].Density(table=((Den*1.1023113109244E-12, ), ))  # convert the density kg/m3 to Ton/mm3
		mdb.models['Model-1'].HomogeneousSolidSection(material=Mat_Name, name=
			Mat_Name, thickness=None)
		mdb.models['Model-1'].HomogeneousSolidSection(material=Mat_Name, name=
			Mat_Name, thickness=None)
		PP4.Set(cells=
			PP4.cells.getByBoundingBox(-50,-50,-50,50,50,50), name='Set-2')
		PP4.SectionAssignment(offset=0.0, 
			offsetField='', offsetType=MIDDLE_SURFACE, region=
			PP4.sets['Set-2'], sectionName=
			Mat_Name, thicknessAssignment=FROM_SECTION)
		# ************************************* For Mesh only *************************************************	
	PP4.seedPart(deviationFactor=0.1, 
		minSizeFactor=0.1, size=0.35)
	PP4.setElementType(elemTypes=(ElemType(
		elemCode=C3D8R, elemLibrary=EXPLICIT, secondOrderAccuracy=OFF, 
		kinematicSplit=AVERAGE_STRAIN, hourglassControl=DEFAULT, 
		distortionControl=DEFAULT), ElemType(elemCode=C3D6, elemLibrary=EXPLICIT), 
		ElemType(elemCode=C3D4, elemLibrary=EXPLICIT)), regions=(
		PP4.cells.getByBoundingBox(-50,-50,-50,50,50,50), ))
	PP4.generateMesh()
	# ******************************** For the job ****************
	mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
    description='', echoPrint=OFF, explicitPrecision=SINGLE, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='Job-e1', nodalOutputPrecision=SINGLE, 
    numCpus=1, numDomains=1, parallelizationMethodExplicit=DOMAIN, queue=None, 
    resultsFormat=ODB, scratch='', type=ANALYSIS, userSubroutine='', waitHours=
    0, waitMinutes=0)