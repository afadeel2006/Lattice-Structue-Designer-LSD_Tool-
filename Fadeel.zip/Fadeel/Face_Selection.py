	# Import the modules used by this script.

	from abaqus import *
	from abaqusConstants import *
	import part
	import assembly
	import step
	import load
	import interaction

	myModel = mdb.models['Model-1']

	# Create a new Viewport for this example.

	myViewport=session.Viewport(name='Region syntax', 
				   origin=(20, 20), width=200, height=100)

	# Create a Sketch and draw two rectangles. 

	mySketch = myModel.ConstrainedSketch(name='Sketch A',
		sheetSize=200.0)

	mySketch.rectangle(point1=(-40.0, 30.0),
		point2=(-10.0, 0.0))

	mySketch.rectangle(point1=(10.0, 30.0),
		point2=(40.0, 0.0))

	# Create a 3D part and extrude the rectangles.

	door = myModel.Part(name='Door',
		dimensionality=THREE_D, type=DEFORMABLE_BODY)

	door.BaseSolidExtrude(sketch=mySketch, depth=20.0)

	# Instance the part.

	myAssembly = myModel.rootAssembly
	doorInstance = myAssembly.Instance(name='Door-1',
		part=door)

	# Select two vertices.

	pillarVertices = doorInstance.vertices.findAt(
		((-40,30,0),), ((40,0,0),) )

	# Create a static step.

	myModel.StaticStep(name='impact',
		previous='Initial', initialInc=1, timePeriod=1)

	# Create a concentrated force on the selected
	# vertices.

	myPillarLoad = myModel.ConcentratedForce(
		name='pillarForce', createStepName='impact',
		region=(pillarVertices,), cf1=12.50E4)

	# Select two faces

	topFace = doorInstance.faces.findAt(((-25,30,10),))
	bottomFace = doorInstance.faces.findAt(((-25,0,10),))

	# Create a pressure load on the selected faces.
	# You can use the "+" notation if the entities are of
	# the same type and are from the same part instance.

	myFenderLoad = myModel.Pressure(
		name='pillarPressure', createStepName='impact',
		region=((topFace+bottomFace, SIDE1),),
		magnitude=10E4)

	# Select two edges from one instance.

	myEdge1 = doorInstance.edges.findAt(((10,15,20),))
	myEdge2 = doorInstance.edges.findAt(((10,15,0),))

	# Create a boundary condition on one face,
	# two edges, and two vertices.

	myDisplacementBc= myModel.DisplacementBC(
		name='xBC', createStepName='impact',
		region=(pillarVertices, myEdge1+myEdge2,
		topFace), u1=5.0)

	# Select two faces using an arbitrary point
	# on the face.

	faceRegion = doorInstance.faces.findAt(
		((-30,15,20), ), ((30,15,20),))

	# Create a surface containing the two faces.
	# Indicate which side of the surface to include.

	mySurface = myModel.rootAssembly.Surface(
		name='exterior', side1Faces=faceRegion)

	# Create an elastic foundation using the surface.

	myFoundation = myModel.ElasticFoundation(
		 name='elasticFloor', createStepName='Initial',
		 surface=mySurface, stiffness=1500)

	# Display the assembly along with the new boundary
	# conditions and loads.

	myViewport.setValues(displayedObject=myAssembly)
	myViewport.assemblyDisplay.setValues(step='impact', 
		loads=ON, bcs=ON, fields=ON)
